package com.telematicssdk.tracking

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.Location
import androidx.core.content.IntentCompat
import com.telematicssdk.tracking.model.sensor.Event
import com.telematicssdk.tracking.utils.ApiCallbackDispatcher

abstract class TrackingEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {

        when (IntentCompat.getSerializableExtra(intent, ACTION, Actions::class.java)) {
            null -> {}
            Actions.LOCATION -> {
                val location = IntentCompat.getParcelableExtra(intent, VALUE, Location::class.java)
                location?.let {
                    dispatchSafely { onLocationChanged(context, location) }
                }

            }

            Actions.TRACK_STARTED -> {
                dispatchSafely { onStartTracking(context) }
            }

            Actions.TRACK_STOPPED -> {
                dispatchSafely { onStopTracking(context) }
            }

            Actions.SPEED_VIOLATION -> {
                val violation =
                    IntentCompat.getParcelableExtra(intent, VALUE, SpeedViolation::class.java)
                violation?.let {
                    dispatchSafely { onSpeedViolation(context, violation) }
                }
            }

            Actions.NEW_EVENTS -> {
                val events = IntentCompat.getParcelableArrayExtra(intent, VALUE, Event::class.java)
                    ?.filterIsInstance<Event>()?.toTypedArray()
                if (!events.isNullOrEmpty()) {
                    dispatchSafely { onNewEvents(context, events) }
                }
            }

            Actions.SDK_DEPRECATED -> {
                dispatchSafely { onSdkDeprecated(context) }
            }
        }

    }

    private fun dispatchSafely(block: () -> Unit) {
        ApiCallbackDispatcher.dispatch {
            try {
                block()
            } catch (_: Exception) {

            }
        }
    }

    abstract fun onLocationChanged(context: Context, location: Location)

    abstract fun onStartTracking(context: Context)

    abstract fun onStopTracking(context: Context)

    abstract fun onSpeedViolation(context: Context, violation: SpeedViolation)

    abstract fun onNewEvents(context: Context, events: Array<Event>)

    abstract fun onSdkDeprecated(context: Context)

}

internal const val ACTION = "TrackingEventsReceiver.ACTION"
internal const val VALUE = "TrackingEventsReceiver.VALUE"

internal enum class Actions {
    LOCATION,
    TRACK_STARTED,
    TRACK_STOPPED,
    SPEED_VIOLATION,
    NEW_EVENTS,
    SDK_DEPRECATED
}

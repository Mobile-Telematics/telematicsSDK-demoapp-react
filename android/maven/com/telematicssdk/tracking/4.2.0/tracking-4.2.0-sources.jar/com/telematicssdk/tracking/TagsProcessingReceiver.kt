package com.telematicssdk.tracking

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.IntentCompat
import com.telematicssdk.tracking.model.database.models.raw_tags.Action
import com.telematicssdk.tracking.model.database.models.raw_tags.Status
import com.telematicssdk.tracking.server.model.sdk.raw_tags.Tag
import com.telematicssdk.tracking.utils.ApiCallbackDispatcher

abstract class TagsProcessingReceiver : BroadcastReceiver(), TagsProcessingListener {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val action =
                IntentCompat.getSerializableExtra(intent, ACTION, Action::class.java) ?: return
            val status =
                IntentCompat.getSerializableExtra(intent, STATUS, Status::class.java) ?: return
            when (action) {
                Action.ACTIVATE -> {
                    val data =
                        IntentCompat.getParcelableExtra(intent, DATA, Tag::class.java) ?: return
                    val time = intent.getLongExtra(TIME, 0)
                    dispatchSafely { onTagAdd(status, data, time) }
                }

                Action.DEACTIVATE -> {
                    val data =
                        IntentCompat.getParcelableExtra(intent, DATA, Tag::class.java) ?: return
                    val time = intent.getLongExtra(TIME, 0)
                    dispatchSafely { onTagRemove(status, data, time) }
                }

                Action.DEACTIVATE_ALL -> {
                    val data = intent.extras!!.getInt(DATA, 0)
                    val time = intent.getLongExtra(TIME, 0)
                    dispatchSafely { onAllTagsRemove(status, data, time) }
                }

                Action.GET_TAGS -> {
                    val data = IntentCompat.getParcelableArrayExtra(intent, DATA, Tag::class.java)
                        ?.filterIsInstance<Tag>()?.toTypedArray()
                    val time = intent.getLongExtra(TIME, 0)
                    dispatchSafely { onGetTags(status, data, time) }
                }
            }

        } catch (_: Exception) {

        }

    }

    private fun dispatchSafely(block: () -> Unit) {
        ApiCallbackDispatcher.dispatch {
            try {
                block()
            } catch (_: Exception) {

            }
        }
    }

    companion object {
        internal const val ACTION = "TagsProcessingReceiver.ACTION"
        internal const val STATUS = "TagsProcessingReceiver.STATUS"
        internal const val DATA = "TagsProcessingReceiver.VALUE"
        internal const val TIME = "TagsProcessingReceiver.TIME"
    }
}

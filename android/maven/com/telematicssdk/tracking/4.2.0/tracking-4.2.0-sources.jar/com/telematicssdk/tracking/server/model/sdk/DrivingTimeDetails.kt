package com.telematicssdk.tracking.server.model.sdk

data class DrivingTimeDetails(
    /**
     * Counts rush hours driving.
     */
    val rushHours: Double,

    /**
     * Counts hours driving in night.
     */
    val nightHours: Double,

    /**
     * Diving time scoring.
     */
    val ratingTimeOfDay: Double,

    /**
     * Total Driving Time in hours.
     */
    val totalDriveTimeHours: Double,

    /**
     * Average Daily Driving in min.
     */
    val dailyAverageDrivingTimeMin: Double,

    /**
     * Night hours diagram for period in hrs/date.
     */
    val nightHoursDiagram: Array<DiagramEntity>?,

    /**
     * Rush hours diagram for period in hrs/time.
     */
    val rushHoursDiagram: Array<DiagramEntity>?,

    /**
     * Day hours diagram for period in hrs/time.
     */
    val dayHoursDiagram: Array<DiagramEntity>?
)
package com.telematicssdk.tracking.server.model.sdk

data class DrivingDetails(
    /**
     * Common Driving rating.
     * Range 0...100
     */
    val drivingRating: Int,

    /**
     * Frequency of harsh braking per 100km
     */
    val heavyBrakingFrequencyFor100Km: Int,

    /**
     * Frequency of rapid accelerations per 100km
     */
    val activeAccelerationFrequencyFor100Km: Int,

    /**
     * Harsh Braking during this period
     */
    val heavyBrakingCountForPeriod: Int,

    /**
     * Rapid Accelerations for period
     */
    val activeAccelerationCountForPeriod: Int,

    /**
     * Harsh Braking diagram data for period
     */
    val heavyBrakingDiagrams: Array<DiagramEntity>?,

    /**
     * Rapid Accelerations diagram data for period count/date
     */
    val activeAccelerationDiagram: Array<DiagramEntity>?
)
package com.telematicssdk.tracking.server.model.sdk.raw_tags

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Tag(val tag: String?, val source: String?) : Parcelable {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || other !is Tag) return false
        return this.tag == other.tag
    }

    override fun hashCode(): Int {
        return tag.hashCode() * 31 +
                source.hashCode()
    }

    override fun toString(): String {
        return "Tag(tag=$tag, source=$source)"
    }
}

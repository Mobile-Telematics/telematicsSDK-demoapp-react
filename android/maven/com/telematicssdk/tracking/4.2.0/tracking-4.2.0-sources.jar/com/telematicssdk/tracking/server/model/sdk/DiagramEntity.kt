package com.telematicssdk.tracking.server.model.sdk

data class DiagramEntity(
    val date: String?,
    val value: Int
)
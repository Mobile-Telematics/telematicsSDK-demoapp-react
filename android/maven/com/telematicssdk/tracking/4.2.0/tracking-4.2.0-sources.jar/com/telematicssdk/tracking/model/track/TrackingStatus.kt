package com.telematicssdk.tracking.model.track

enum class TrackingStatus(val value: String) {
    ENABLED("Enabled"),
    DEVICE_ID_NOT_SET("Device ID not set"),
    SDK_DISABLED("SDK disabled"),
    DISABLED_BY_SETTINGS("Disabled by SDK settings"),
    DISABLED_BY_SERVER("Disabled by server"),
    DISABLED_BY_SCHEDULE("Disabled by schedule")
}
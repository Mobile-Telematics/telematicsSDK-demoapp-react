package com.telematicssdk.tracking.model

import java.util.Locale

enum class UserStatus(val id: Int) {
    ACTIVE(1),
    DEACTIVATED(2),
    DELETED(3),
    SUSPENDED(4),
    NOT_FOUND(5),
    UNKNOWN(0);

    companion object {
        fun parse(s: String): UserStatus {
            return when (s.lowercase(Locale.ROOT)) {
                "active" -> ACTIVE
                "deactivated" -> DEACTIVATED
                "deleted" -> DELETED
                "suspended" -> SUSPENDED
                "notfound" -> NOT_FOUND
                else -> getDefault()
            }
        }

        fun parse(value: Int): UserStatus {
            return when (value) {
                ACTIVE.id -> ACTIVE
                DEACTIVATED.id -> DEACTIVATED
                DELETED.id -> DELETED
                SUSPENDED.id -> SUSPENDED
                NOT_FOUND.id -> NOT_FOUND
                else -> getDefault()
            }
        }

        fun getDefault() = UNKNOWN
    }
}

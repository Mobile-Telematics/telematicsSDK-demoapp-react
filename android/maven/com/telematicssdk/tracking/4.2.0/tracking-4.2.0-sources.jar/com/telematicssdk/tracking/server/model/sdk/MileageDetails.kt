package com.telematicssdk.tracking.server.model.sdk

data class MileageDetails(
    /**
     * Mileage rating range 0..100
     */
    val mileageRating: Int,

    /**
     * Average Mileage for week in km
     */
    val averageMileageForWeek: Float,//Средний пробег за неделю

    /**
     * Average Mileage for month in km
     */
    val averageMileageForMonth: Float,//Ср за месяц

    /**
     * Total mileage in km
     */
    val mileageSummary: Float,//Суммарный пробег

    /**
     * Predicted annual mileage in km
     */
    val expectedYearMileage: Float,//Ожидаемый за год

    /**
     * Diagram data mileage for period km/date
     */
    val mileageDiagram: Array<DiagramEntity>?

)
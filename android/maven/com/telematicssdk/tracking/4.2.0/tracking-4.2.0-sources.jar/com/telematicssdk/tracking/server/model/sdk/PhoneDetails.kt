package com.telematicssdk.tracking.server.model.sdk

data class PhoneDetails(
    /**
     * Phone Usage while driving scoring.
     * Range 0...100
     */
    val rating: Int,

    /**
     * Phone Usage while driving in min.
     */
    val phoneUse: Int,

    /**
     * Phone Usage while driving with speed > 20km/h in min.
     */
    val phoneUseOver20km: Int,

    /**
     * Phone Usage while driving diagram min/date.
     */
    val usingPhoneWhileDrivingDiagram: Array<DiagramEntity>?,

    /**
     * Phone Usage while driving with speed > 20km/h diagram min/date.
     */
    val usingPhoneWhileDrivingOverSpeedLimitDiagram: Array<DiagramEntity>?
)
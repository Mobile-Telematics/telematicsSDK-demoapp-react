package com.telematicssdk.tracking.server.model.sdk

data class DashboardInfo(
    /**
     * The user rating points.
     * Range 0..100.
     */
    val rating: Int,

    /**
     * The user discount points in percentage.
     * Range 0...100
     */
    val discount: Int,

    /**
     * The common driving level.
     * Range 0...100
     */
    val drivingLevel: Int,

    /**
     * The common speed level.
     * Range 0...100
     */
    val speedLevel: Int,

    /**
     * The common mileage level.
     * Range 0...100
     */
    val mileageLevel: Int,

    /**
     * The phone usage level.
     * Range 0...100
     */
    val phoneLevel: Int,

    /**
     * The time of days level.
     * Range 0...100
     */
    val timeOfDayScore: Int
)
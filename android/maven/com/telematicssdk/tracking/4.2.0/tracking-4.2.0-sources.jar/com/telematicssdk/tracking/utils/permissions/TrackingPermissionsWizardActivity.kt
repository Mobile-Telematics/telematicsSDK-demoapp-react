package com.telematicssdk.tracking.utils.permissions

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.SystemBarStyle
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.telematicssdk.tracking.utils.BatteryUtils
import com.telematicssdk.tracking.utils.LocationUtils
import com.telematicssdk.tracking.utils.permissions.components.TrackingPermissionsWizardScreen

class TrackingPermissionsWizardActivity : AppCompatActivity() {

    private lateinit var controller: TrackingPermissionsWizardController

    private var uiState by mutableStateOf<TrackingPermissionsWizardUiState>(
        TrackingPermissionsWizardUiState.Page(null)
    )
    private var pendingStep: TrackingPermissionsWizardStep? = null
    private var pendingSettingsStep: TrackingPermissionsWizardStep? = null
    private var showSettingsFallbackForPendingStep = false
    private var showSettingsDialogForStep by mutableStateOf<TrackingPermissionsWizardStep?>(null)
    private var showCloseDialog by mutableStateOf(false)
    private var isWaitingForSettingsReturn = false

    private val requestLocationPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        val step = pendingStep ?: return@registerForActivityResult
        controller.record(step, controller.isStepGranted(step))
        pendingStep = null
        if (showSettingsFallbackForPendingStep) {
            maybeShowSettingsDialogAfterDenied(step)
        }
        showSettingsFallbackForPendingStep = false
        renderNext()
    }

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) {
        val step = pendingStep ?: return@registerForActivityResult
        controller.record(step, controller.isStepGranted(step))
        pendingStep = null
        if (showSettingsFallbackForPendingStep) {
            maybeShowSettingsDialogAfterDenied(step)
        }
        showSettingsFallbackForPendingStep = false
        renderNext()
    }

    private val requestActivity = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        val step = pendingStep ?: return@registerForActivityResult
        val granted = when (step) {
            TrackingPermissionsWizardStep.Gps -> LocationUtils.isGpsAvailable(this)
            TrackingPermissionsWizardStep.BatteryOptimization ->
                !BatteryUtils.checkBatteryOptimized(this)
            else -> controller.isStepGranted(step)
        }
        controller.record(step, granted)
        pendingStep = null
        if (!granted && showSettingsFallbackForPendingStep) {
            showSettingsDialogForStep = step
        }
        showSettingsFallbackForPendingStep = false
        renderNext()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyThemeMode()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
        )

        controller = TrackingPermissionsWizardController(this)

        onBackPressedDispatcher.addCallback(this) {
            if (!isEarlyExitBlocked()) {
                showCloseDialog = true
            }
        }

        renderNext()

        val appName = applicationInfo.loadLabel(packageManager).toString()
        setContent {
            TrackingPermissionsWizardScreen(
                state = uiState,
                appName = appName,
                themeMode = themeMode(),
                blockEarlyExit = isEarlyExitBlocked(),
                skipWizardPages = shouldSkipWizardPages(),
                showSettingsDialogForStep = showSettingsDialogForStep,
                showCloseDialog = showCloseDialog,
                onContinue = { step -> request(step, showSettingsFallback = false) },
                onStatusStepClick = { step ->
                    request(
                        step = step,
                        showSettingsFallback = step != TrackingPermissionsWizardStep.Gps,
                    )
                },
                onExit = { finishNotAllGranted() },
                onOpenSettings = { step ->
                    showSettingsDialogForStep = null
                    pendingSettingsStep = step
                    isWaitingForSettingsReturn = true
                    controller.openAppSettings()
                },
                onDismissSettings = {
                    showSettingsDialogForStep = null
                },
                onConfirmClose = {
                    showCloseDialog = false
                    setResult(WIZARD_RESULT_CANCELED)
                    finish()
                },
                onDismissClose = {
                    showCloseDialog = false
                },
            )
        }
    }

    override fun onResume() {
        super.onResume()
        val step = pendingSettingsStep ?: return
        if (!isWaitingForSettingsReturn) return

        isWaitingForSettingsReturn = false
        controller.record(step, controller.isStepGranted(step))
        pendingSettingsStep = null
        showSettingsFallbackForPendingStep = false
        renderNext()
    }

    private fun renderNext() {
        if (shouldSkipWizardPages()) {
            if (controller.isAllGranted()) {
                setResult(WIZARD_RESULT_ALL_GRANTED)
                finish()
            } else {
                uiState = TrackingPermissionsWizardUiState.Status(controller.status())
            }
            return
        }

        val page = controller.buildNextPage()
        if (page == null) {
            if (controller.isAllGranted()) {
                setResult(WIZARD_RESULT_ALL_GRANTED)
                finish()
            } else {
                uiState = TrackingPermissionsWizardUiState.Status(controller.status())
            }
        } else {
            uiState = TrackingPermissionsWizardUiState.Page(page)
        }
    }

    private fun request(
        step: TrackingPermissionsWizardStep,
        showSettingsFallback: Boolean,
    ) {
        pendingStep = step
        showSettingsFallbackForPendingStep = showSettingsFallback
        val started = when (step) {
            TrackingPermissionsWizardStep.Location -> {
                controller.requestLocationPermissions(requestLocationPermissions::launch)
                true
            }
            TrackingPermissionsWizardStep.BackgroundLocation ->
                controller.requestBackgroundLocation(requestPermission::launch)
            TrackingPermissionsWizardStep.ActivityRecognition ->
                controller.requestActivityRecognition(requestPermission::launch)
            TrackingPermissionsWizardStep.Gps ->
                controller.requestGps(requestActivity::launch)
            TrackingPermissionsWizardStep.BatteryOptimization ->
                controller.requestBatteryOptimization(requestActivity::launch)
        }

        if (!started) {
            pendingStep = null
            pendingSettingsStep = null
            isWaitingForSettingsReturn = false
            showSettingsFallbackForPendingStep = false
            if (showSettingsFallback) {
                showSettingsDialogForStep = step
            }
            controller.record(step, false)
            renderNext()
        }
    }

    private fun maybeShowSettingsDialogAfterDenied(step: TrackingPermissionsWizardStep) {
        if (controller.isStepGranted(step)) return

        val permission = when (step) {
            TrackingPermissionsWizardStep.Location -> android.Manifest.permission.ACCESS_FINE_LOCATION
            TrackingPermissionsWizardStep.BackgroundLocation ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    android.Manifest.permission.ACCESS_BACKGROUND_LOCATION
                } else {
                    null
                }
            TrackingPermissionsWizardStep.ActivityRecognition ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    android.Manifest.permission.ACTIVITY_RECOGNITION
                } else {
                    null
                }
            else -> null
        }

        if (permission == null || !shouldShowRequestPermissionRationale(permission)) {
            showSettingsDialogForStep = step
        }
    }

    private fun finishNotAllGranted() {
        setResult(WIZARD_RESULT_NOT_ALL_GRANTED)
        finish()
    }

    private fun applyThemeMode() {
        delegate.localNightMode = when (themeMode()) {
            TrackingPermissionsWizardThemeMode.Light -> AppCompatDelegate.MODE_NIGHT_NO
            TrackingPermissionsWizardThemeMode.Dark -> AppCompatDelegate.MODE_NIGHT_YES
            TrackingPermissionsWizardThemeMode.System -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
    }

    private fun themeMode(): TrackingPermissionsWizardThemeMode {
        return TrackingPermissionsWizardThemeMode.from(intent?.getStringExtra(EXTRA_THEME_MODE))
    }

    private fun isEarlyExitBlocked(): Boolean {
        return intent?.getBooleanExtra(EXTRA_BLOCK_EARLY_EXIT, false) == true
    }

    private fun shouldSkipWizardPages(): Boolean {
        return intent?.getBooleanExtra(EXTRA_SKIP_WIZARD_PAGES, false) == true
    }

    companion object {
        const val WIZARD_PERMISSIONS_CODE = 50005
        const val WIZARD_RESULT_CANCELED = 0
        const val WIZARD_RESULT_NOT_ALL_GRANTED = 1
        const val WIZARD_RESULT_ALL_GRANTED = -1

        private const val EXTRA_THEME_MODE = "tracking_permissions_wizard_theme_mode"
        private const val EXTRA_SKIP_WIZARD_PAGES = "tracking_permissions_wizard_skip_wizard_pages"

        @JvmStatic
        @JvmOverloads
        fun getStartWizardIntent(
            context: Context,
            themeMode: TrackingPermissionsWizardThemeMode = TrackingPermissionsWizardThemeMode.System,
            blockEarlyExit: Boolean = false,
            skipWizardPages: Boolean = false,
        ): Intent = Intent(context, TrackingPermissionsWizardActivity::class.java)
            .apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_THEME_MODE, themeMode.value)
                putExtra(EXTRA_BLOCK_EARLY_EXIT, blockEarlyExit)
                putExtra(EXTRA_SKIP_WIZARD_PAGES, skipWizardPages)
            }

        private const val EXTRA_BLOCK_EARLY_EXIT = "tracking_permissions_wizard_block_early_exit"
    }
}

internal sealed interface TrackingPermissionsWizardUiState {
    data class Page(val page: TrackingPermissionsWizardPageState?) : TrackingPermissionsWizardUiState
    data class Status(
        val statuses: List<TrackingPermissionsWizardStepStatus>,
    ) : TrackingPermissionsWizardUiState
}

enum class TrackingPermissionsWizardThemeMode(val value: String) {
    Light("light"),
    Dark("dark"),
    System("system");

    companion object {
        fun from(value: String?): TrackingPermissionsWizardThemeMode {
            return entries.firstOrNull { it.value == value } ?: System
        }
    }
}

package com.telematicssdk.tracking.server.model

enum class StatisticPeriod {
    DAY,
    WEEK,
    TWO_WEEKS,
    ALL_TIME
}
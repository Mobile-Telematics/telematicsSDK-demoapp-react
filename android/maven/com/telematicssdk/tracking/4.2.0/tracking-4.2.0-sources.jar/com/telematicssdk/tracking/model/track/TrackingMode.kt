package com.telematicssdk.tracking.model.track

enum class TrackingMode(val value: String) {
    Standard("Automatic"),
    Persistent("Persistent")
}
package com.telematicssdk.tracking.model.track

import com.telematicssdk.tracking.model.prefs.DeviceIdRegistrationStatus

data class DeviceIdRegistrationState(
    val status: DeviceIdRegistrationStatus,
    val checkedAtMillis: Long?
)
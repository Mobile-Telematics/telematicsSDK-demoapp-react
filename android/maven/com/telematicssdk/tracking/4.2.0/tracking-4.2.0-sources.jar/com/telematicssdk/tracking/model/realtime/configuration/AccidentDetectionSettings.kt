package com.telematicssdk.tracking.model.realtime.configuration

data class AccidentDetectionSettings(
    val speedTime: Int,
    val accidentThreshold: Double,
    val lowSpeedThreshold: Double
)

enum class AccidentDetectionSensitivity(val preset: AccidentDetectionSettings) {
    Sensitive(
        AccidentDetectionSettings(
            speedTime = 35000, // Longer sensitive speed window.
            accidentThreshold = 3.5, // Lower sensitive impact threshold in g.
            lowSpeedThreshold = 2.06 // Keep SSD threshold unchanged to avoid walking/running triggers.
        )
    ),
    Normal(
        AccidentDetectionSettings(
            speedTime = 30000, // CADANS SVP/MP window.
            accidentThreshold = 4.0, // CADANS impact threshold in g.
            lowSpeedThreshold = 2.06 // CADANS slow-speed threshold.
        )
    ),
    Tough(
        AccidentDetectionSettings(
            speedTime = 15000, // Shorter tough speed window.
            accidentThreshold = 4.5, // Higher tough impact threshold in g.
            lowSpeedThreshold = 2.5 // Stricter tough slow-speed threshold.
        )
    )
}


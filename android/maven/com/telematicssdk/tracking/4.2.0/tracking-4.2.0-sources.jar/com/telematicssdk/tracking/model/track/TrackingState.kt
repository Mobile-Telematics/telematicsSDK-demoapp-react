package com.telematicssdk.tracking.model.track

import com.telematicssdk.tracking.model.track.TrackingStatus

data class TrackingState(
    val automaticTrackingStatus: TrackingStatus,
    val manualTrackingStatus: TrackingStatus
)
package com.telematicssdk.tracking

/**
 * Represent setting sdk.
 * It must be pass in Tracking.initialize().
 */
class Settings {

    companion object {

        @JvmStatic
        val accuracyLow = 500

        @JvmStatic
        val accuracyNormal = 300

        @JvmStatic
        val accuracyHigh = 100

        @JvmStatic
        val stopTrackingTimeLow = 1

        @JvmStatic
        val stopTrackingTimeNormal = 3

        @JvmStatic
        val stopTrackingTimeHigh = 5
    }

    var accuracy: Int = 0
        private set
    var stopTrackingTimeout: Int = 0
        private set
    var isAutoStartOn: Boolean = true
        private set
    var isPassiveDetectionOn: Boolean = false
        private set


    /**
     * Default Setting constructor
     * Stop tracking time is 5 minute.
     * Parking radius is 100 meters.
     * Auto start tracking is true.
     * Passive detection is false
     */
    constructor() {
        accuracy = accuracyHigh
        stopTrackingTimeout = stopTrackingTimeHigh
        isAutoStartOn = true
        isPassiveDetectionOn = false
    }


    /**
     * Setting constructor
     *
     * @param accuracy - parking radius.
     */
    fun accuracy(accuracy: Int): Settings {
        this.accuracy = accuracy
        return this
    }

    /**
     * Setting constructor
     *
     * @param stopTrackingTimeout - stop Tracking timeout.
     */
    fun stopTrackingTimeout(stopTrackingTimeout: Int): Settings {
        this.stopTrackingTimeout = stopTrackingTimeout
        return this
    }

    /**
     * Setting constructor
     *
     * @param autoStartOn - true if autostart is on and false is one off.
     */
    fun autoStartOn(autoStartOn: Boolean): Settings {
        this.isAutoStartOn = autoStartOn
        return this
    }

    /**
     * Setting constructor
     *
     * Retained for compatibility; accident detection is controlled by the server.
     */
    @Deprecated("Accident detection is controlled by the server configuration.")
    @Suppress("UNUSED_PARAMETER")
    fun adOn(adOn: Boolean): Settings {
        return this
    }

    /**
     * Setting constructor
     *
     * @param passiveDetectionOn - true if passive detection is on and false if it is off.
     */
    fun passiveDetectionOn(passiveDetectionOn: Boolean): Settings {
        this.isPassiveDetectionOn = passiveDetectionOn
        return this
    }

    override fun toString(): String {
        return "Settings(accuracy=$accuracy, stopTrackingTimeout=$stopTrackingTimeout, isAutoStartOn=$isAutoStartOn, isPassiveDetectionOn=$isPassiveDetectionOn)"
    }
}

package com.telematicssdk.tracking.model

import java.util.Date

data class SdkConfig(
    val deviceId: String,
    val accidents: Accidents,
    val debug: Debug,
    val heartbeats: Heartbeats,
    val liveTracking: LiveTracking,
    val schedule: Schedule,
    val tripsTracking: TripsTracking,
    val user: User,
    val isFetchedFromServer: Boolean,
    val configFetchedAt: Date?,
    val sensors: Sensors
) {

    data class Accidents(
        val enabled: Boolean,
        val enableBufferRawSamples: Boolean,
        val bufferRawSamplesMode: RawSamplesMode
    )

    /** Which raw sensor buffers are retained when raw sample buffering is enabled. */
    enum class RawSamplesMode { CONFIRMED_ONLY, ALL_CANDIDATES }

    data class Sensors(val accelerometer: Sensor, val gyroscope: Sensor)

    data class Sensor(val rateHz: Double)

    data class Debug(
        val logs: Logs
    )

    data class Logs(
        val enabled: Boolean
    )

    data class Heartbeats(
        val mode: HeartbeatsMode
    )

    data class LiveTracking(
        val enabled: Boolean,
        val endpoint: String,
        val frqSec: Long,
        val imei: String,
        val port: Int,
        val topic: String,
        val type: Int
    )

    data class Schedule(
        val enabled: Boolean
    )

    data class TripsTracking(
        val enabled: Boolean,
        val enablePointQuantiles: Boolean
    )

    data class User(
        val status: UserStatus
    )

}


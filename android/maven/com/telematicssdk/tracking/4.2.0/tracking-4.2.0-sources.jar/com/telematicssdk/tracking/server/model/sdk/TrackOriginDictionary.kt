package com.telematicssdk.tracking.server.model.sdk

data class TrackOriginDictionary(
    /**
     * The human-readable name.
     */
    var name: String? = null,

    /**
     * The trip type code.
     */
    var code: String? = null,

    var canBeSelected: Boolean = false
)
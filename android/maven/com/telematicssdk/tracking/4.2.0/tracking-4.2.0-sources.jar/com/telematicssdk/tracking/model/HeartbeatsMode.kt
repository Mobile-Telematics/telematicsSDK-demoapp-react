package com.telematicssdk.tracking.model

import java.util.Locale

enum class HeartbeatsMode(val id: Int) {
    DISABLED(0),
    STANDARD(1),
    EXTENDED(2);

    companion object {
        fun parse(s: String): HeartbeatsMode {
            return when (s.lowercase(Locale.ROOT)) {
                "disabled" -> DISABLED
                "standard" -> STANDARD
                "extended" -> EXTENDED
                else -> getDefault()
            }
        }

        fun parse(value: Int): HeartbeatsMode {
            return when (value) {
                DISABLED.id -> DISABLED
                STANDARD.id -> STANDARD
                EXTENDED.id -> EXTENDED
                else -> getDefault()
            }
        }

        fun getDefault() = STANDARD
    }
}
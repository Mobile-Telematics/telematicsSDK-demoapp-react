package com.telematicssdk.tracking.server.model.sdk

data class Track(
    /**
     * The start address.
     */
    var addressStart: String? = null,

    /**
     * The end address.
     */
    var addressEnd: String? = null,

    /**
     * The start date in "yyyy-MM-dd'T'HH:mm:ss ZZ" format.
     */
    var endDate: String? = null,

    /**
     * The end date in "yyyy-MM-dd'T'HH:mm:ss ZZ" format.
     */
    var startDate: String? = null,

    /**
     * The unique trip id.
     */
    var trackId: String? = null,

    /**
     * The count of sharp acceleration.
     */
    var accelerationCount: Int = 0,

    /**
     * The count of sharp braking.
     */
    var decelerationCount: Int = 0,

    /**
     * The distance trip in km.
     */
    var distance: Double = 0.toDouble(),

    /**
     * The duration trip in horse.
     */
    var duration: Double = 0.toDouble(),

    /**
     * The trip rating. Range 1..5
     */
    var rating: Double = 0.toDouble(),

    /**
     * The trip phone usage minutes.
     */
    var phoneUsage: Double = 0.toDouble(),

    /**
     * The trip type.
     * See also [TripOriginDictionary.code]
     */
    var originalCode: String? = null,

    /**
     * The trip type has changed. If false - origin trip type can be changed. If false - can't be changed.
     * [TripOriginDictionary.code]
     */
    var hasOriginChanged: Boolean = false,

    /**
     * Total distance travelled(in km) while exceeding speed limit over for 10 to 20 km/h
     */
    var midOverSpeedMileage: Double = 0.toDouble(),

    /**
     * Total distance travelled(in km) while exceeding speed limit over for 20 km/h or more.
     */
    var highOverSpeedMileage: Double = 0.toDouble(),

    /**
     * Driving tips.
     */
    var drivingTips: String? = null,

    var shareType: String? = null,

    var cityStart: String? = null,

    var cityFinish: String? = null,

    var ratingCornering: Double = 0.toDouble(),

    var ratingAcceleration: Double = 0.toDouble(),

    var ratingBraking: Double = 0.toDouble(),

    var ratingSpeeding: Double = 0.toDouble(),

    var ratingPhoneDistraction: Double = 0.toDouble(),

    var ratingTimeOfDay: Double = 0.toDouble(),

    /**
     * The trip rating. Range 0..100
     */
    var rating100: Double = 0.toDouble(),

    var ratingCornering100: Double = 0.toDouble(),

    var ratingAcceleration100: Double = 0.toDouble(),

    var ratingBraking100: Double = 0.toDouble(),

    var ratingSpeeding100: Double = 0.toDouble(),

    var ratingPhoneDistraction100: Double = 0.toDouble(),

    var ratingTimeOfDay100: Double = 0.toDouble(),

    val addressStartParts: AddressParts?,

    val addressFinishParts: AddressParts?,

    /**
     * List of tags.
     */
    val tags: Array<TrackTag>?
) {
    override fun toString(): String {
        return "Track(addressStart=$addressStart, addressEnd=$addressEnd, endDate=$endDate, startDate=$startDate, trackId=$trackId, accelerationCount=$accelerationCount, decelerationCount=$decelerationCount, distance=$distance, duration=$duration, rating=$rating, phoneUsage=$phoneUsage, originalCode=$originalCode, hasOriginChanged=$hasOriginChanged, midOverSpeedMileage=$midOverSpeedMileage, highOverSpeedMileage=$highOverSpeedMileage, drivingTips=$drivingTips, shareType=$shareType, cityStart=$cityStart, cityFinish=$cityFinish, ratingCornering=$ratingCornering, ratingAcceleration=$ratingAcceleration, ratingBraking=$ratingBraking, ratingSpeeding=$ratingSpeeding, ratingPhoneDistraction=$ratingPhoneDistraction, ratingTimeOfDay=$ratingTimeOfDay, rating100=$rating100, ratingCornering100=$ratingCornering100, ratingAcceleration100=$ratingAcceleration100, ratingBraking100=$ratingBraking100, ratingSpeeding100=$ratingSpeeding100, ratingPhoneDistraction100=$ratingPhoneDistraction100, ratingTimeOfDay100=$ratingTimeOfDay100, addressStartParts=$addressStartParts, addressFinishParts=$addressFinishParts, tags=${tags?.contentToString()})"
    }
}
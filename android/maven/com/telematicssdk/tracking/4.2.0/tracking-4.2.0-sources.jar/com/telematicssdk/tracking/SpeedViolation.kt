package com.telematicssdk.tracking

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class SpeedViolation(
    val date: Long,
    val latitude: Double,
    val long: Double,
    val yourSpeed: Float,
    val speedLimit: Float
) : Parcelable
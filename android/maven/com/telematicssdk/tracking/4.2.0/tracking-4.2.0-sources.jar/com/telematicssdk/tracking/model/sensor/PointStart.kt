package com.telematicssdk.tracking.model.sensor

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.telematicssdk.tracking.utils.Scale
import kotlinx.parcelize.Parcelize

@Parcelize
data class PointStart(

    /**
     *
     * @return
     * The latitude
     */
    /**
     *
     * @param Latitude
     * The latitude
     */
    @Scale(5)
    @SerializedName("Latitude")
    var latitude: Double = 0.0,
    /**
     *
     * @return
     * The longitude
     */
    /**
     *
     * @param Longitude
     * The longitude
     */ //    @Override
    @Scale(5)
    @SerializedName("Longitude")
    var longitude: Double = 0.0

    //    public String toString() {
//        return ToStringBuilder.reflectionToString(this);
//    }
) : Parcelable {
    override fun toString(): String {
        return "PointStart{" +
                "latitude=" + latitude +
                ", longitude=" + longitude +
                '}'
    }
}
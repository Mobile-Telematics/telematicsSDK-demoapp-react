package com.telematicssdk.tracking;

public interface TrackingStateListener {

    void onStartTracking();

    void onStopTracking();
}

package com.telematicssdk.tracking.server.model.sdk

data class AddressParts(
    val countryCode: String?,
    val country: String?,
    val county: String?,
    val postalCode: String?,
    val state: String?,
    val city: String?,
    val distinct: String?,
    val street: String?,
    val house: String?
) {
    override fun toString(): String {
        return "AddressParts(countryCode=$countryCode, country=$country, county=$county, postalCode=$postalCode, state=$state, city=$city, distinct=$distinct, street=$street, house=$house)"
    }
}
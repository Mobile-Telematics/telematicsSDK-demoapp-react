package com.telematicssdk.tracking.server.model

enum class Locale {
    EN,
    RU,
    PT,
    ES
}
package com.telematicssdk.tracking.utils.permissions

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Color as AndroidColor
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.telematicssdk.tracking.R
import com.telematicssdk.tracking.utils.BatteryUtils
import com.telematicssdk.tracking.utils.LocationUtils
import com.telematicssdk.tracking.utils.permissions.components.SettingsDialog
import com.telematicssdk.tracking.utils.permissions.components.TrackingPermissionsWizardStatus
import com.telematicssdk.tracking.utils.permissions.components.wizardColors

class TrackingPermissionsWizardStatusDialogFragment : DialogFragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isCancelable = !blockEarlyExit()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        return ComposeView(requireContext()).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                TrackingPermissionsWizardStatusDialogContent(
                    themeMode = themeMode(),
                    blockEarlyExit = blockEarlyExit(),
                    onDismissRequest = { dismissAllowingStateLoss() },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setBackgroundDrawable(ColorDrawable(AndroidColor.TRANSPARENT))
        dialog?.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        )
    }

    private fun themeMode(): TrackingPermissionsWizardThemeMode {
        return TrackingPermissionsWizardThemeMode.from(arguments?.getString(ARG_THEME_MODE))
    }

    private fun blockEarlyExit(): Boolean {
        return arguments?.getBoolean(ARG_BLOCK_EARLY_EXIT, false) == true
    }

    companion object {
        const val TAG = "TrackingPermissionsWizardStatusDialogFragment"

        private const val ARG_THEME_MODE = "tracking_permissions_wizard_status_dialog_theme_mode"
        private const val ARG_BLOCK_EARLY_EXIT =
            "tracking_permissions_wizard_status_dialog_block_early_exit"

        @JvmStatic
        @JvmOverloads
        fun newInstance(
            themeMode: TrackingPermissionsWizardThemeMode =
                TrackingPermissionsWizardThemeMode.System,
            blockEarlyExit: Boolean = false,
        ): TrackingPermissionsWizardStatusDialogFragment {
            return TrackingPermissionsWizardStatusDialogFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_THEME_MODE, themeMode.value)
                    putBoolean(ARG_BLOCK_EARLY_EXIT, blockEarlyExit)
                }
            }
        }
    }
}

@Composable
fun TrackingPermissionsWizardStatusDialog(
    themeMode: TrackingPermissionsWizardThemeMode = TrackingPermissionsWizardThemeMode.System,
    blockEarlyExit: Boolean = false,
    onDismissRequest: () -> Unit,
) {
    Dialog(
        onDismissRequest = {
            if (!blockEarlyExit) {
                onDismissRequest()
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = !blockEarlyExit,
            dismissOnClickOutside = !blockEarlyExit,
            usePlatformDefaultWidth = false,
        ),
    ) {
        TrackingPermissionsWizardStatusDialogContent(
            themeMode = themeMode,
            blockEarlyExit = blockEarlyExit,
            onDismissRequest = onDismissRequest,
        )
    }
}

@Composable
private fun TrackingPermissionsWizardStatusDialogContent(
    themeMode: TrackingPermissionsWizardThemeMode,
    blockEarlyExit: Boolean,
    onDismissRequest: () -> Unit,
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() } ?: return
    val controller = remember(activity) { TrackingPermissionsWizardController(activity) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val colors = wizardColors(themeMode.isDark())
    val appName = remember(activity) {
        activity.applicationInfo.loadLabel(activity.packageManager).toString()
    }

    var statuses by remember { mutableStateOf(controller.status()) }
    var pendingStep by remember { mutableStateOf<TrackingPermissionsWizardStep?>(null) }
    var pendingSettingsStep by remember { mutableStateOf<TrackingPermissionsWizardStep?>(null) }
    var showSettingsFallbackForPendingStep by remember { mutableStateOf(false) }
    var showSettingsDialogForStep by remember {
        mutableStateOf<TrackingPermissionsWizardStep?>(null)
    }

    fun refreshStatus() {
        statuses = controller.status()
    }

    fun showSettingsDialogAfterDeniedIfNeeded(step: TrackingPermissionsWizardStep) {
        if (shouldShowSettingsDialogAfterDenied(activity, controller, step)) {
            showSettingsDialogForStep = step
        }
    }

    val requestLocationPermissions = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        val step = pendingStep ?: return@rememberLauncherForActivityResult
        controller.record(step, controller.isStepGranted(step))
        pendingStep = null
        if (showSettingsFallbackForPendingStep) {
            showSettingsDialogAfterDeniedIfNeeded(step)
        }
        showSettingsFallbackForPendingStep = false
        refreshStatus()
    }

    val requestPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) {
        val step = pendingStep ?: return@rememberLauncherForActivityResult
        controller.record(step, controller.isStepGranted(step))
        pendingStep = null
        if (showSettingsFallbackForPendingStep) {
            showSettingsDialogAfterDeniedIfNeeded(step)
        }
        showSettingsFallbackForPendingStep = false
        refreshStatus()
    }

    val requestActivity = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        val step = pendingStep ?: return@rememberLauncherForActivityResult
        val granted = when (step) {
            TrackingPermissionsWizardStep.Gps -> LocationUtils.isGpsAvailable(activity)
            TrackingPermissionsWizardStep.BatteryOptimization ->
                !BatteryUtils.checkBatteryOptimized(activity)
            else -> controller.isStepGranted(step)
        }
        controller.record(step, granted)
        pendingStep = null
        if (!granted && showSettingsFallbackForPendingStep) {
            showSettingsDialogForStep = step
        }
        showSettingsFallbackForPendingStep = false
        refreshStatus()
    }

    fun request(step: TrackingPermissionsWizardStep, showSettingsFallback: Boolean) {
        pendingStep = step
        showSettingsFallbackForPendingStep = showSettingsFallback
        val started = when (step) {
            TrackingPermissionsWizardStep.Location -> {
                controller.requestLocationPermissions(requestLocationPermissions::launch)
                true
            }
            TrackingPermissionsWizardStep.BackgroundLocation ->
                controller.requestBackgroundLocation(requestPermission::launch)
            TrackingPermissionsWizardStep.ActivityRecognition ->
                controller.requestActivityRecognition(requestPermission::launch)
            TrackingPermissionsWizardStep.Gps ->
                controller.requestGps(requestActivity::launch)
            TrackingPermissionsWizardStep.BatteryOptimization ->
                controller.requestBatteryOptimization(requestActivity::launch)
        }

        if (!started) {
            pendingStep = null
            showSettingsFallbackForPendingStep = false
            if (showSettingsFallback) {
                showSettingsDialogForStep = step
            }
            controller.record(step, false)
            refreshStatus()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event != Lifecycle.Event.ON_RESUME) return@LifecycleEventObserver
            val step = pendingSettingsStep ?: return@LifecycleEventObserver
            controller.record(step, controller.isStepGranted(step))
            pendingSettingsStep = null
            showSettingsFallbackForPendingStep = false
            refreshStatus()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(statuses) {
        if (controller.isAllGranted()) {
            onDismissRequest()
        }
    }

    Surface(
        modifier = Modifier
            .padding(horizontal = 24.dp)
            .widthIn(max = 560.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = colors.gradientEnd,
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(listOf(colors.gradientStart, colors.gradientEnd))
                )
                .padding(horizontal = 24.dp, vertical = 24.dp),
        ) {
            TrackingPermissionsWizardStatus(
                statuses = statuses,
                appName = appName,
                colors = colors,
                blockEarlyExit = blockEarlyExit,
                onStatusStepClick = { step ->
                    request(
                        step = step,
                        showSettingsFallback = step != TrackingPermissionsWizardStep.Gps,
                    )
                },
                onExit = onDismissRequest,
                modifier = Modifier.heightIn(max = 640.dp),
                showHeaderIcon = false,
                titleRes = R.string.tracking_permissions_wizard_status_attention_title,
            )
        }
    }

    if (showSettingsDialogForStep != null) {
        SettingsDialog(
            step = showSettingsDialogForStep!!,
            colors = colors,
            onOpenSettings = { step ->
                showSettingsDialogForStep = null
                pendingSettingsStep = step
                controller.openAppSettings()
            },
            onDismiss = {
                showSettingsDialogForStep = null
            },
        )
    }
}

private fun Context.findActivity(): Activity? {
    return when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }
}

private fun shouldShowSettingsDialogAfterDenied(
    activity: Activity,
    controller: TrackingPermissionsWizardController,
    step: TrackingPermissionsWizardStep,
): Boolean {
    if (controller.isStepGranted(step)) return false

    val permission = when (step) {
        TrackingPermissionsWizardStep.Location -> android.Manifest.permission.ACCESS_FINE_LOCATION
        TrackingPermissionsWizardStep.BackgroundLocation ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                android.Manifest.permission.ACCESS_BACKGROUND_LOCATION
            } else {
                null
            }
        TrackingPermissionsWizardStep.ActivityRecognition ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                android.Manifest.permission.ACTIVITY_RECOGNITION
            } else {
                null
            }
        else -> null
    }

    return permission == null || !activity.shouldShowRequestPermissionRationale(permission)
}

@Composable
private fun TrackingPermissionsWizardThemeMode.isDark(): Boolean {
    return when (this) {
        TrackingPermissionsWizardThemeMode.Light -> false
        TrackingPermissionsWizardThemeMode.Dark -> true
        TrackingPermissionsWizardThemeMode.System ->
            androidx.compose.foundation.isSystemInDarkTheme()
    }
}

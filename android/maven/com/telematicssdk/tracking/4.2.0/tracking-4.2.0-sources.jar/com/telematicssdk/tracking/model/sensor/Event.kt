package com.telematicssdk.tracking.model.sensor

import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.telematicssdk.tracking.utils.Scale
import kotlinx.parcelize.Parcelize

@Parcelize
data class Event(

    @SerializedName("Type")
    var type: String? = null,

    @SerializedName("TimeStart")
    var timeStart: Double = 0.0,

    @SerializedName("Duration")
    var duration: Double = 0.0,

    @SerializedName("PureDuration")
    var pureDuration: Double = 0.0,

    @Scale(2)
    @SerializedName("SpeedStart")
    var speedStart: Double = 0.0,

    @Scale(2)
    @SerializedName("SpeedStop")
    var speedStop: Double = 0.0,

    @Scale(2)
    @SerializedName("SpeedMedian")
    var speedMedian: Double = 0.0,

    @Scale(2)
    @SerializedName("PrevEventSpeed")
    var prevEventSpeed: Double = 0.0,

    @Scale(4)
    @SerializedName("AccelerationDirect")
    var accelerationDirect: Double = 0.0,

    @Scale(4)
    @SerializedName("AccelerationLateral")
    var accelerationLateral: Double = 0.0,

    @Scale(4)
    @SerializedName("AccelerationVertical")
    var accelerationVertical: Double = 0.0,

    @Scale(4)
    @SerializedName("AccelerationDirectEnd")
    var accelerationDirectEnd: Double = 0.0,

    @Scale(4)
    @SerializedName("AccelerationLateralEnd")
    var accelerationLateralEnd: Double = 0.0,

    @Scale(4)
    @SerializedName("AccelerationVerticalEnd")
    var accelerationVerticalEnd: Double = 0.0,

    @SerializedName("PointStart")
    var pointStart: PointStart? = null,

    @SerializedName("PointEnd")
    var pointEnd: PointEnd? = null,

    @SerializedName("RangeDirect")
    var rangeDirect: RangeValue? = null,

    @SerializedName("RangeLateral")
    var rangeLateral: RangeValue? = null,

    @SerializedName("RangeVertical")
    var rangeVertical: RangeValue? = null,

    @SerializedName("Accuracy")
    var rangeAccuracy: RangeValue? = null,

    @SerializedName("Speed")
    var rangeSpeed: RangeValue? = null,

    @SerializedName("SpeedBefore10s")
    var rangeSpeedBefore10s: RangeValue? = null,

    @SerializedName("SpeedBefore20s")
    var rangeSpeedBefore20s: RangeValue? = null,

    @SerializedName("SpeedAfter10s")
    var rangeSpeedAfter10s: RangeValue? = null,

    @SerializedName("SpeedAfter20s")
    var rangeSpeedAfter20s: RangeValue? = null,

    @SerializedName("AccidentTrigger")
    var accidentTrigger: String? = null,

    @Scale(4)
    @SerializedName("Reliability")
    var reliability: Double = 0.0,

    @SerializedName("Id")
    var uuid: String? = null

) : Parcelable {
    override fun toString(): String {
        return "Event(type=$type, timeStart=$timeStart, duration=$duration, pureDuration=$pureDuration, speedStart=$speedStart, speedStop=$speedStop, speedMedian=$speedMedian, prevEventSpeed=$prevEventSpeed, accelerationDirect=$accelerationDirect, accelerationLateral=$accelerationLateral, accelerationVertical=$accelerationVertical, accelerationDirectEnd=$accelerationDirectEnd, accelerationLateralEnd=$accelerationLateralEnd, accelerationVerticalEnd=$accelerationVerticalEnd, pointStart=$pointStart, pointEnd=$pointEnd, rangeDirect=$rangeDirect, rangeLateral=$rangeLateral, rangeVertical=$rangeVertical, rangeAccuracy=$rangeAccuracy, rangeSpeed=$rangeSpeed, rangeSpeedBefore10s=$rangeSpeedBefore10s, rangeSpeedBefore20s=$rangeSpeedBefore20s, rangeSpeedAfter10s=$rangeSpeedAfter10s, rangeSpeedAfter20s=$rangeSpeedAfter20s, accidentTrigger=$accidentTrigger, reliability=$reliability, id=$uuid)"
    }

    fun toShortString(): String {
        return "Event(type=$type, duration=$duration, speedStart=$speedStart, speedStop=$speedStop, pointStart=$pointStart, pointEnd=$pointEnd, id=$uuid)"
    }

    fun toJson(): String {
        return Gson().toJson(this)
    }

}
package com.telematicssdk.tracking.server.model

import com.google.gson.annotations.SerializedName
import com.telematicssdk.tracking.utils.Scale

data class TrackLastKnownPoint(
    @Scale(5)
    @SerializedName("Latitude")
    val latitude: Double = 0.0,
    @SerializedName("Longitude")
    @Scale(5)
    val longitude: Double = 0.0,
    @SerializedName("Accuracy")
    @Scale(2)
    val accuracy: Float = 0f,
    @SerializedName("PointDate")
    val date: String? = null,
    @SerializedName("PointOrigin")
    val origin: String? = null
)

package com.telematicssdk.tracking.model.prefs

enum class DeviceIdRegistrationStatus(val value: String) {
    NOT_SET("Device ID not set"),
    UNKNOWN("Unknown"),
    REGISTERED("Registered"),
    NOT_REGISTERED("Not registered")
}

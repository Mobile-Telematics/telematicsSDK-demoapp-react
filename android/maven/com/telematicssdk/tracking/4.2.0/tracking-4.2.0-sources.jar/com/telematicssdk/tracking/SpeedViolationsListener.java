package com.telematicssdk.tracking;

public interface SpeedViolationsListener {
    void onSpeedViolation(SpeedViolation violation);
}

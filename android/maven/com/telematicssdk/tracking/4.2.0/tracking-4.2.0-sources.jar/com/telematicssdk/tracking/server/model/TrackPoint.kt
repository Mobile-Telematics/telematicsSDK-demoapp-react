package com.telematicssdk.tracking.server.model

import com.google.gson.annotations.SerializedName
import com.telematicssdk.tracking.model.sensor.RangeValue
import com.telematicssdk.tracking.utils.Scale

data class TrackPoint(

    @SerializedName("Number")
    var number: Int = 0,

    @Scale(2)
    @SerializedName("TotalMeters")
    var totalMeters: Double = 0.toDouble(),

    @Scale(2)
    @SerializedName("Speed")
    var speed: Double = 0.toDouble(),

    @Scale(2)
    @SerializedName("CalcSpeed")
    var calcSpeed: Double = 0.toDouble(),

    @Scale(5)
    @SerializedName("Latitude")
    var latitude: Double = 0.toDouble(),

    @Scale(5)
    @SerializedName("Longitude")
    var longitude: Double = 0.toDouble(),

    @Scale(2)
    @SerializedName("Accuracy")
    var accuracy: Float = 0.toFloat(),

    @Scale(2)
    @SerializedName("SpeedAccuracy")
    var speedAccuracy: Float = 0.toFloat(),

    @Scale(2)
    @SerializedName("VerticalAccuracy")
    var verticalAccuracy: Float = 0.toFloat(),

    @Scale(2)
    @SerializedName("CourseAccuracy")
    var courseAccuracy: Float = 0.toFloat(),

    @Scale(4)
    @SerializedName("Pressure")
    var pressure: Float? = null,

    @SerializedName("LocationMocked")
    var locationMocked: Boolean? = null,

    @SerializedName("SatellitesUsed")
    var satellitesUsed: Int? = null,

    @SerializedName("StepCount")
    var stepCount: Int? = null,

    @SerializedName("PointDate")
    var pointDate: String,

    @Scale(1)
    @SerializedName("Height")
    var height: Double = 0.toDouble(),

    @Scale(2)
    @SerializedName("Course")
    var course: Double = 0.toDouble(),

    @Scale(2)
    @SerializedName("Yaw")
    var yaw: Double = 0.toDouble(),

    @Scale(4)
    @SerializedName("Lateral")
    var lateral: Double = 0.toDouble(),

    @SerializedName("ScreenEnabled")
    var screenEnabled: Boolean = false,

    @SerializedName("DeviceBlocked")
    var deviceBlocked: Boolean = true,

    @SerializedName("TickTimestamp")
    var tickTimestamp: Long = 0,

    @Scale(4)
    @SerializedName("Acceleration")
    var acceleration: Double = 0.toDouble(),

    @Scale(4)
    @SerializedName("Deceleration")
    var deceleration: Double = 0.toDouble(),

    @Scale(4)
    @SerializedName("AccelerationX")
    var accelerationX: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("AccelerationY")
    var accelerationY: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("AccelerationZ")
    var accelerationZ: Double = 0.toDouble(),

    @Scale(4)
    @SerializedName("GyroscopeX")
    var gyroscopeX: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("GyroscopeY")
    var gyroscopeY: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("GyroscopeZ")
    var gyroscopeZ: Double = 0.toDouble(),

    @Scale(4)
    @SerializedName("AccelerationXOriginal")
    var accelerationXOriginal: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("AccelerationYOriginal")
    var accelerationYOriginal: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("AccelerationZOriginal")
    var accelerationZOriginal: Double = 0.toDouble(),

    @Scale(4)
    @SerializedName("GyroscopeXOriginal")
    var gyroscopeXOriginal: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("GyroscopeYOriginal")
    var gyroscopeYOriginal: Double = 0.toDouble(),
    @Scale(4)
    @SerializedName("GyroscopeZOriginal")
    var gyroscopeZOriginal: Double = 0.toDouble(),

    @SerializedName("Quantile")
    var quantile: HashMap<String, RangeValue>?,

    @SerializedName("PointTimestampMs")
    var pointTimestampMs: Long? = null,

    @SerializedName("TickTimestampMs")
    var tickTimestampMs: Long? = null
)

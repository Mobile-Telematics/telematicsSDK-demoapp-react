package com.telematicssdk.tracking

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import android.util.Log
import androidx.annotation.RequiresPermission
import androidx.annotation.AnyThread
import com.telematicssdk.tracking.extensions.isValidGuid
import com.telematicssdk.tracking.model.SdkConfig
import com.telematicssdk.tracking.model.prefs.SdkSettings
import com.telematicssdk.tracking.model.realtime.configuration.AccidentDetectionSensitivity
import com.telematicssdk.tracking.model.realtime.configuration.AccidentDetectionSettings
import com.telematicssdk.tracking.model.track.DeviceIdRegistrationState
import com.telematicssdk.tracking.model.track.TrackingMode
import com.telematicssdk.tracking.model.track.TrackingState
import com.telematicssdk.tracking.server.model.Locale
import com.telematicssdk.tracking.server.model.StatisticPeriod
import com.telematicssdk.tracking.server.model.Track
import com.telematicssdk.tracking.server.model.sdk.*
import com.telematicssdk.tracking.utils.*
import com.telematicssdk.tracking.utils.logmanager.ModulesPrefixes
import com.telematicssdk.tracking.utils.logmanager.SdkLogger
import java.io.IOException
import java.util.Date

/**
 * Before start using SDK Api, you need to call [initialize].
 * Strongly recommend to run this method at your <tt>Application</tt> class extension.
 *
 * Once you got <tt>Device ID</tt>, call [setDeviceID].
 * That means sdk at this moment able to sync all gathered data.
 *
 * To run SDK, call [setEnableSdk].
 * The state of the call saved and you don't need to call this method again after application re-launched.
 *
 * Use methods to get sdk statistics:
 *
 * [getDashboardInfo]
 *
 * [getDrivingDetailsStatistics]
 *
 * [getDrivingTimeDetailsStatistics]
 *
 * [getMileageDetailsStatistics]
 *
 * [getPhoneDetailStatistics]
 *
 * [getSpeedDetailStatistics]
 *
 * [getTrackDetails]
 *
 * [getTrackOriginDict]
 *
 * [getTracks]
 *
 * [getUnsentTrips]
 *
 * You must call this methods only after [initialize] and [setDeviceID] called.
 */
class TrackingApi private constructor() {

    companion object {
        private val TAG = TrackingApi::class.java.simpleName

        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var instance: TrackingApi? = null

        /**
         * Gets the singleton instance of the [TrackingApi].
         *
         * This method provides a global access point to the `TrackingApi` object,
         * ensuring that only one instance of the class is created and used throughout the application.
         * It uses a thread-safe, double-checked locking pattern to initialize the instance on its first call.
         *
         * Before using any other methods in the SDK, you must first obtain the instance using this function
         * and then call [initialize].
         *
         * @return The singleton instance of [TrackingApi].
         */
        @JvmStatic
        fun getInstance(): TrackingApi {
            if (instance == null) {
                synchronized(TrackingApi::class.java) {
                    instance = TrackingApi()
                }
            }
            return instance!!
        }

        const val SPEED_VIOLATION_KEY = "tracking.intent.key.speed.violation"
    }

    /**
     * @return sdk initialized stater, true - if initialized.
     */
    @Volatile
    private var isInitialized = false
    private lateinit var context: Context
    private lateinit var delegate: TrackingDelegate

    /**
     * Initializes the SDK. This method must be called once, preferably in your `Application` class,
     * before using any other SDK functionality.
     *
     * Calling this method when the SDK is already initialized will have no effect, and a warning
     * will be logged.
     *
     * @param context The application context. The SDK will use `context.applicationContext` to
     * avoid memory leaks.
     * @param settings Optional [Settings] for customizing the SDK's behavior. If `null`, default
     * settings will be used.
     * @throws IllegalArgumentException if the provided `context` is null, or if any of the values
     * in the `settings` object are invalid (e.g., negative `accuracy` or `stopTrackingTimeout`).
     */
    @Synchronized
    fun initialize(context: Context, settings: Settings?) {
        checkNotNullContext(context)
        val ctx = context.applicationContext
        if (isInitialized) {
            SdkLogger.sdkLogger?.warn(
                ctx,
                ModulesPrefixes.CORE,
                TAG,
                "call initialize(), already initialized"
            )
        } else {

            if (!ProcessUtils.isMainProcess(context)) {
                val processName = ProcessUtils.getCurrentProcessName(context)
                Log.w(TAG,"SDK init skipped in non-main process: $processName")
                return
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    val userManager = context.getSystemService(UserManager::class.java)
                    val userUnlocked = userManager?.isUserUnlocked == true
                    if (!userUnlocked) return
                } catch (_: Exception) {

                }
            }

            if (settings != null) {
                checkSettings(settings)
            }
            SdkLogger.sdkLogger?.info(
                ctx,
                ModulesPrefixes.CORE,
                TAG,
                "call initialize(), ${settings.toString()}"
            )
            this.context = ctx
            delegate = TrackingDelegate()
            delegate.initialize(ctx, settings)
            isInitialized = true
            delegate.queue.reconcileRawBuffers()
        }
    }

    /**
     * Initializes the SDK. This method must be called once, preferably in your `Application` class, before using any other SDK features.
     *
     * This function performs the initial setup of the SDK. If the SDK has already been initialized, this method will log a warning and do nothing.
     * It also checks if the device user is unlocked on Android N (API 24) and above before proceeding.
     *
     * @param context The application context.
     * @throws IllegalArgumentException if `context` is `null` or if any of the provided [Settings] values are invalid (e.g., negative accuracy).
     */
    @Synchronized
    fun initialize(context: Context) {
        initialize(context, null)
    }

    /**
     * Checks if the SDK has been initialized.
     *
     * This function returns the current initialization state of the SDK. The SDK is considered
     * initialized after a successful call to the [initialize] method.
     *
     * @return `true` if the SDK has been initialized, `false` otherwise.
     * @see initialize
     */
    @Synchronized
    fun isInitialized(): Boolean {
        return isInitialized
    }

    /**
     * Sets the device ID for the SDK and enables data synchronization.
     *
     * This ID is crucial for associating tracking data with a specific device. Once set, the SDK can
     * begin synchronizing all gathered data with the server.
     *
     * The `deviceId` is persisted locally, so you only need to call this method once, typically
     * after the user registers or logs in. It's not necessary to call it again on subsequent
     * application launches unless the device ID changes (e.g., user logs out and a new user
     * logs in).
     * If the ID differs from the active track owner when the next point is processed by the SDK
     * queue, that point is discarded and the track is stopped with reason `DeviceIdChanged`,
     * without a forced restart. Existing stop conditions, including the schedule, may stop it earlier.
     * Device IDs are compared without regard to case. A track owned by another ID is not resumed.
     *
     * @param deviceId The unique identifier for the device, which you must obtain from your backend
     *                 during the device registration process. It must be a valid GUID string.
     * @throws IllegalArgumentException if the provided `deviceId` is not a valid GUID.
     * @throws IllegalStateException if the SDK has not been initialized via [initialize].
     * @see initialize
     * @see isDeviceIdValid
     * @see clearDeviceID
     */
    @Synchronized
    fun setDeviceID(deviceId: String) {
        checkInitialized()
        if (!deviceId.isValidGuid()) {
            SdkLogger.sdkLogger?.warn(context, ModulesPrefixes.CORE, TAG, "setDeviceID rejected: invalid device ID")
            throw java.lang.IllegalArgumentException("deviceId must be valid GUID")
        }
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "call setDeviceID(deviceId=$deviceId)")
        delegate.setDeviceID(deviceId)
    }

    /**
     * Checks if the device ID has been set.
     *
     * This function is deprecated and will be removed in a future version.
     * Please use [isDeviceIdValid] to check the validity of the device ID instead.
     * To get the inverse of this check, use `!isDeviceIdValid()`.
     *
     * @return `true` if the device ID has not been set or is invalid, `false` otherwise.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     * @see isDeviceIdValid
     * @deprecated Use `!isDeviceIdValid()` instead.
     */
    @Deprecated(
        message = "Please use !isDeviceIdValid()",
        replaceWith = ReplaceWith(expression = "!isDeviceIdValid()")
    )
    @Synchronized
    fun isDeviceIdEmpty(): Boolean {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "isDeviceIdEmpty")
        return !delegate.isDeviceIdValid()
    }

    /**
     * Checks if the device ID is a valid GUID.
     *
     * This function validates the format of the currently set device ID to ensure it
     * conforms to the Globally Unique Identifier (GUID) standard. A valid device ID is
     * required for the SDK to sync data with the server.
     *
     * @return `true` if the device ID is a valid GUID, `false` otherwise (including if it has not been set).
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     * @see setDeviceID
     * @see getDeviceId
     */
    @Synchronized
    fun isDeviceIdValid(): Boolean {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "isDeviceIdValid")
        return delegate.isDeviceIdValid()
    }

    /**
     * Retrieves the current device ID used by the SDK.
     *
     * The device ID is set using the [setDeviceID] method and is persisted by the SDK.
     * It is essential for synchronizing data with the backend.
     *
     * @return The device ID as a [String]. Returns an empty string if the ID has not been set.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     * @see setDeviceID
     * @see isDeviceIdValid
     */
    fun getDeviceId(): String {
        checkInitialized()
        return delegate.getDeviceId()
    }

    /**
     * Returns server configuration cached for the current device ID.
     *
     * @throws IllegalStateException if the SDK has not been initialized.
     */
    fun getSdkConfig(): SdkConfig {
        checkInitialized()
        return delegate.getSdkConfig()
    }

    /**
     * Starts a server-configuration fetch for the current device ID.
     *
     * A refresh can be started at most once per minute for each device ID.
     *
     * @return `true` when the fetch was queued, `false` when the current device ID is invalid
     * or a refresh for it was already queued within the last minute.
     * @throws IllegalStateException if the SDK has not been initialized.
     */
    fun refreshSdkConfig(): Boolean {
        checkInitialized()
        return delegate.refreshSdkConfig()
    }

    /**
     * Returns the current device ID registration state derived from cached SDK configuration.
     *
     * The status is based on the current device ID and the cached user status. It is
     * [com.telematicssdk.tracking.model.prefs.DeviceIdRegistrationStatus.UNKNOWN]
     * until the configuration is fetched. Clearing the device ID moves the state to
     * [com.telematicssdk.tracking.model.prefs.DeviceIdRegistrationStatus.NOT_SET].
     *
     * @return The current device ID registration state.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @deprecated Use [getSdkConfig] instead.
     */
    @Deprecated("Use getSdkConfig() instead.")
    fun getDeviceIdRegistrationState(): DeviceIdRegistrationState {
        checkInitialized()
        return delegate.getDeviceIdRegistrationState()
    }

    /**
     * Returns the current automatic and manual tracking states cached by the SDK.
     *
     * @return The current tracking state.
     * @throws IllegalStateException if the SDK has not been initialized.
     */
    fun getTrackingState(): TrackingState {
        checkInitialized()
        return delegate.getTrackingState()
    }

    /**
     * Clears the stored device ID from the SDK.
     *
     * After this method is called, the SDK will no longer be associated with a device ID
     * and will stop syncing data until a new device ID is provided using [setDeviceID].
     * This is typically used during a user logout process to disassociate the device
     * from the user's account.
     * If a track is still active when its next point is processed by the SDK queue, that point
     * is discarded and the track is stopped with reason `DeviceIdChanged`, without a forced restart.
     *
     * @throws IllegalStateException if [initialize] has not been called.
     * @see setDeviceID
     * @see isDeviceIdValid
     * @see logout
     */
    @Synchronized
    fun clearDeviceID() {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called clearDeviceID()")
        delegate.clearDeviceID()
    }

    /**
     * Sets SubUnits metadata that will be attached to newly started tracks.
     *
     * SubUnits are a flat dictionary of business identifiers, for example
     * `DriverId` or `VehicleId`. Updating this value does not restart the current track.
     * The value is persisted and is used for new track snapshots until replaced or cleared.
     *
     * @param subUnits Flat SubUnits dictionary. Up to 5 entries. Keys and values must be
     * non-blank and no longer than 255 characters.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @throws IllegalArgumentException if [subUnits] is empty, has more than 5 entries, or
     * contains blank keys/values or keys or values longer than 255 characters. The exception
     * message explains which constraint was violated.
     * @see getSubUnits
     * @see clearSubUnits
     */
    @Synchronized
    fun setSubUnits(subUnits: Map<String, String>) {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called setSubUnits()")
        delegate.setSubUnits(subUnits)
    }

    /**
     * Returns currently persisted SubUnits metadata.
     *
     * @return Flat SubUnits dictionary, or an empty map when unset.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @see setSubUnits
     * @see clearSubUnits
     */
    fun getSubUnits(): Map<String, String> {
        checkInitialized()
        return delegate.getSubUnits()
    }

    /**
     * Clears currently persisted SubUnits metadata.
     *
     * Clearing SubUnits does not restart the current track. Newly started tracks will use an
     * empty SubUnits snapshot.
     *
     * @throws IllegalStateException if the SDK has not been initialized.
     * @see setSubUnits
     * @see getSubUnits
     */
    @Synchronized
    fun clearSubUnits() {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called clearSubUnits()")
        delegate.clearSubUnits()
    }

    /**
     * Sets Properties metadata that will be attached to tracks.
     *
     * Properties are a flat dictionary of business identifiers, for example
     * `order_id` or `shift`. Updating this value replaces the whole dictionary.
     * If a track is currently active and the new dictionary differs from the current one,
     * the SDK restarts the track so each track keeps an immutable Properties snapshot.
     *
     * @param properties Flat Properties dictionary. Up to 20 entries. Keys and values must be
     * non-blank and no longer than 255 characters.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @throws IllegalArgumentException if [properties] is empty, has more than 20 entries, or
     * contains blank keys/values or keys or values longer than 255 characters. The exception
     * message explains which constraint was violated.
     * @see getProperties
     * @see clearProperties
     */
    @Synchronized
    fun setProperties(properties: Map<String, String>) {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called setProperties()")
        delegate.setProperties(properties)
    }

    /**
     * Returns currently persisted Properties metadata.
     *
     * @return Flat Properties dictionary, or an empty map when unset.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @see setProperties
     * @see clearProperties
     */
    fun getProperties(): Map<String, String> {
        checkInitialized()
        return delegate.getProperties()
    }

    /**
     * Clears currently persisted Properties metadata.
     *
     * If a track is currently active and Properties are non-empty, the SDK restarts the track so
     * subsequent tracking uses an empty Properties snapshot.
     *
     * @throws IllegalStateException if the SDK has not been initialized.
     * @see setProperties
     * @see getProperties
     */
    @Synchronized
    fun clearProperties() {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called clearProperties()")
        delegate.clearProperties()
    }

    /**
     * Adds an Activity Log entry to the currently active trip.
     *
     * Activity Log entries are arbitrary business events supplied by the host app, for example
     * delivery or checkpoint events. Entries are stored with the active trip and uploaded in the
     * trip payload as `ActivityLog`.
     *
     * This method does not restart, stop, or split the active trip.
     * The SDK attaches the last known location to the entry when one is available.
     * In some cases this call may take up to 1 second, so it is recommended to call it from a
     * background thread.
     *
     * @param text Entry text. Must be non-blank and no longer than 1000 characters.
     * @param data Optional flat data dictionary. Up to 20 entries. Keys and values must be
     * non-blank and no longer than 255 characters.
     * @throws IllegalStateException if the SDK has not been initialized or there is no active trip.
     * @throws IllegalArgumentException if [text] or [data] violates Activity Log limits.
     */
    @Synchronized
    fun addActivityLog(text: String, data: Map<String, String> = emptyMap()) {
        checkInitialized()
        if (!isTracking()) {
            throw IllegalStateException("ActivityLog can be added only during an active trip")
        }
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called addActivityLog()")
        delegate.addActivityLog(text, data)
    }

    /** Accident detection is controlled by the server configuration and active user. */
    @Deprecated("Accident detection is controlled by the server configuration.")
    @Suppress("UNUSED_PARAMETER")
    fun setAccidentDetectionEnabled(enabled: Boolean) = Unit

    /**
     * Checks if accident detection is enabled in the SDK settings.
     *
     * This returns the effective setting based on the server configuration and active user.
     *
     * @return `true` if accident detection is enabled, `false` otherwise.
     * @throws IllegalStateException if [initialize] never called or SDK is not enabled.
     *
     */
    fun isAccidentDetectionEnabled(): Boolean {
        checkInitialized()
        return delegate.isAccidentDetectionEnabled()
    }

    /**
     * Enables or disables the automatic trip recording feature.
     *
     * This feature, when enabled, allows the SDK to automatically detect and record trips
     * without manual intervention from the user. When disabled, trips must be started
     * manually using [startTracking] or [startPersistentTracking].
     *
     * @param enabled `true` to enable automatic trip recording, `false` to disable it.
     * @param permanent If `true`, this setting will be saved and will persist across app restarts
     *   and SDK re-initializations. If `false`, the setting will be reset to its default value
     *   (as defined in [Settings.isAutoStartOn]) the next time the SDK is initialized.
     * @throws IllegalStateException if [initialize] has not been called or the SDK is not enabled
     *   via [setEnableSdk].
     *
     * @see isAutoStartEnabled
     * @see startTracking
     * @see Settings.isAutoStartOn
     */
    fun setAutoStartEnabled(enabled: Boolean, permanent: Boolean) {
        checkInitialized()
        if (!isSdkEnabled()) throw IllegalStateException("SDK is not enabled. You need to call setEnableSdk(enable: Boolean) method before")
        SdkLogger.sdkLogger?.info(
            context,
            ModulesPrefixes.AD,
            TAG,
            "called setAutoStartEnabled($enabled, $permanent)"
        )
        delegate.setAutoStartEnabled(enabled, permanent)
    }


    /**
     * Checks if automatic start tracking is enabled in the SDK settings.
     *
     * This function retrieves the current state of the auto-start feature, which determines
     * whether the SDK should begin tracking automatically.
     *
     * @return `true` if automatic start is enabled, `false` otherwise.
     * @throws IllegalStateException if [initialize] has not been called.
     *
     * @see setAutoStartEnabled
     * @see Settings.isAutoStartOn
     */
    fun isAutoStartEnabled(): Boolean {
        checkInitialized()
        return SdkSettings(context).isAutoStartOn()
    }

    /**
     * Call this method whenever you need to turn SDK on|off.
     * Turning off will completely disabling SDK. i.e. all push notifications, GPS receivers
     * and so on will be effectively removed or disabled.
     * Sdk saves the state and you don't need to call this method again after application re-launched.
     * Before to call this method, ensure that list of permissions are granted [Manifest.permission.ACCESS_FINE_LOCATION]
     * @param enable true - to enable sdk, false - to disable sdk
     * @throws IllegalStateException if [enable] is true and any of permission is not granted.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    @RequiresPermission(
        anyOf = [
            Manifest.permission.ACCESS_FINE_LOCATION
        ]
    )
    @Synchronized
    fun setEnableSdk(enable: Boolean) {
        checkInitialized()
        SdkLogger.sdkLogger?.info(
            context,
            ModulesPrefixes.CORE,
            TAG,
            "called setEnableSdk($enable)"
        )
        // check permissions status when user want to enable SDK
        if (enable) {
            checkGrantedPermissions()
            delegate.setEnableSdk()
        } else {
            delegate.disableSdkOnUploadComplete()
        }
    }


    @Synchronized
    internal fun setDisableSdk() {
        delegate.setDisableSdk()
    }

    @Synchronized
    internal fun setDisableSdkIfPending() {
        if (delegate.isSdkDisablePending()) {
            delegate.setDisableSdk()
        }
    }

    /**
     * Checks if the SDK is currently enabled and active.
     * This state is controlled by the [setEnableSdk] method.
     *
     * @return `true` if the SDK is enabled, `false` otherwise.
     * @throws IllegalStateException if [initialize] has not been called.
     */
    fun isSdkEnabled(): Boolean {
        checkInitialized()
        val isSdkActive = delegate.isSdkActive()
        SdkLogger.sdkLogger?.info(
            context,
            ModulesPrefixes.CORE,
            TAG,
            "called isSdkEnabled() return $isSdkActive"
        )
        return isSdkActive
    }

    /**
     * Checks if the SDK disable operation is pending.
     *
     * This function indicates whether a request to disable the SDK has been made
     * (e.g., by calling `setEnableSdk(false)`), but the SDK is still performing
     * final operations, such as uploading the last trip data, before completely shutting down.
     *
     * This is useful for providing user feedback that the SDK is in the process of turning off.
     *
     * @return `true` if the SDK is in the process of being disabled, `false` otherwise.
     * @see setEnableSdk
     * @see isSdkEnabled
     */
    fun isSdkDisablePending(): Boolean {
        checkInitialized()
        val isSdkDisablePending = delegate.isSdkDisablePending()
        SdkLogger.sdkLogger?.info(
            context,
            ModulesPrefixes.CORE,
            TAG,
            "called isSdkDisablePending() return $isSdkDisablePending"
        )
        return isSdkDisablePending
    }

    /**
     * Logs the user out of the SDK.
     *
     * This function performs the following actions:
     * 1. Checks if the SDK has been initialized. If not, it will throw an exception.
     * 2. Logs an informational message indicating that the logout function has been called.
     * 3. Delegates the logout process to the `delegate` object.
     * 4. Within the delegate, it:
     *    - Disables the SDK by calling `setDisableSdk()`.
     *    - Clears the device ID by calling `clearDeviceID()`.
     *
     * This method is synchronized to ensure thread safety, preventing concurrent access and potential data corruption during the logout process.
     *
     * @throws IllegalStateException if the SDK has not been initialized before calling this function.
     */
    @Synchronized
    fun logout() {
        checkInitialized()
        SdkLogger.sdkLogger?.info(
            context,
            ModulesPrefixes.CORE,
            TAG,
            "called logout()"
        )
        delegate.logout()
    }

    /**
     * Determines whether the manufacturer-specific power-saving settings screen needs to be displayed.
     *
     * Some device manufacturers (e.g., Huawei, Xiaomi, Samsung) have custom battery optimization
     * settings that can interfere with background processes, such as GPS tracking. This function
     * checks if the current device is from a manufacturer known to have such settings and if the
     * user has not yet been shown a screen to disable these optimizations for the app.
     *
     * This is useful for prompting the user to adjust their device settings to ensure the SDK can
     * function correctly in the background.
     *
     * @return `true` if the manufacturer settings screen should be shown, `false` otherwise.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     */
    fun isManufactureSettingsNeedToBeShown(): Boolean {
        checkInitialized()
        return delegate.isManufactureSettingsNeedToBeShown()
    }

    /**
     * Checks if all required permissions and sensors have been granted.
     *
     * This function is deprecated. Please use [areAllRequiredPermissionsAndSensorsGranted] instead.
     *
     * This function delegates the actual check to the internal delegate.
     * It ensures that the necessary initialization has been performed before
     * invoking the delegate's method.
     *
     * @return `true` if all required permissions and sensors are granted, `false` otherwise.
     * @throws IllegalStateException if the necessary initialization has not been performed.
     * @see areAllRequiredPermissionsAndSensorsGranted
     */
    @Deprecated(
        message = "Please use areAllRequiredPermissionsAndSensorsGranted()",
        replaceWith = ReplaceWith(expression = "areAllRequiredPermissionsAndSensorsGranted()")
    )
    fun isAllRequiredPermissionsAndSensorsGranted(): Boolean {
        return areAllRequiredPermissionsAndSensorsGranted()
    }

    /**
     * @suppress Since 1.25.1, use [areAllRequiredPermissionsGranted] instead.
     * @return `true` if all required permissions are granted, `false` otherwise.
     * @throws IllegalStateException if the library is not initialized.
     */
    @Deprecated(
        message = "Please use areAllRequiredPermissionsGranted()",
        replaceWith = ReplaceWith(expression = "areAllRequiredPermissionsGranted()")
    )
    fun isAllRequiredPermissionsGranted(): Boolean {
        return areAllRequiredPermissionsGranted()
    }

    /**
     * Checks if all required permissions and sensors have been granted.
     *
     * This function delegates the actual check to the internal delegate.
     * It ensures that the necessary initialization has been performed before
     * invoking the delegate's method.
     *
     * @return `true` if all required permissions and sensors are granted, `false` otherwise.
     * @throws IllegalStateException if the necessary initialization has not been performed.
     */
    fun areAllRequiredPermissionsAndSensorsGranted(): Boolean {
        checkInitialized()
        return delegate.isAllRequiredPermissionsAndSensorsGranted()
    }

    /**
     * Checks if all required permissions are granted.
     *
     * This function delegates the actual check to the internal `delegate`.
     *
     * @return `true` if all required permissions are granted, `false` otherwise.
     * @throws IllegalStateException if the library is not initialized.
     */
    fun areAllRequiredPermissionsGranted(): Boolean {
        checkInitialized()
        return delegate.isAllRequiredPermissionsGranted()
    }

    /**
     * Checks if a track is currently being recorded.
     *
     * @return `true` if tracking is in progress, `false` otherwise.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     */
    @Synchronized
    fun isTracking(): Boolean {
        checkInitialized()
        return delegate.isTracking()
    }

    /**
     * Manually starts a new tracking session.
     *
     * Requires `ACCESS_FINE_LOCATION` or `ACCESS_COARSE_LOCATION` and device location to be enabled;
     * returns `false` otherwise.
     * This function will only start tracking if the SDK is enabled and not already tracking.
     * The session uses the current [TrackingMode]. If [getTrackingMode] returns
     * [TrackingMode.Standard], the track will automatically stop after a period of inactivity.
     * If [getTrackingMode] returns [TrackingMode.Persistent], the track will continue until
     * [stopTracking] is called or the maximum persistent tracking interval is reached.
     *
     * @return `true` if tracking was successfully started, `false` otherwise (e.g., if the SDK is disabled or already tracking).
     * @throws IllegalStateException if [initialize] has not been called.
     * @see isTracking
     * @see isSdkEnabled
     * @see getTrackingMode
     * @see setTrackingMode
     * @see stopTracking
     */
    @Synchronized
    fun startTracking(): Boolean {
        checkInitialized()
        if (!ContextUtils.hasAnyLocationPermission(context) || !ContextUtils.isLocationEnabled(context)) {
            SdkLogger.sdkLogger?.warn(
                context, ModulesPrefixes.CORE, TAG,
                "called startTracking() ignored: location permission is missing or device location is disabled"
            )
            return false
        }
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called startTracking()")
        val sdkActive = delegate.isSdkActive()
        val isCurrentlyTracking = isTracking()
        if (sdkActive && !isCurrentlyTracking) {
            if (delegate.getTrackingMode() == TrackingMode.Persistent) {
                delegate.startTrackAsPersistent()
            } else {
                delegate.startTracking()
            }
            return true
        } else {
            SdkLogger.sdkLogger?.warn(
                context, ModulesPrefixes.CORE, TAG, "called startTracking() ignored " +
                        "(isSdkActive=$sdkActive, isCurrentlyTracking=$isCurrentlyTracking)"
            )
        }
        return false
    }
    /**
     * Starts a persistent tracking session.
     *
     * Requires `ACCESS_FINE_LOCATION` or `ACCESS_COARSE_LOCATION` and device location to be enabled;
     * returns `false` otherwise.
     * This function will only start tracking if the SDK is enabled and not already tracking.
     * The track will continue until [stopTracking] is called or the maximum persistent
     * tracking interval is reached.
     *
     * @return `true` if the tracking session was successfully started, `false` otherwise (e.g., if the SDK is disabled or already tracking).
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @see startTrackAsPersistent
     * @see stopTracking
     */
    @Deprecated(
        message = "Use startTrackAsPersistent()",
        replaceWith = ReplaceWith("startTrackAsPersistent()")
    )
    @Synchronized
    fun startPersistentTracking(): Boolean {
        return startTrackAsPersistent()
    }

    /**
     * Manually starts a persistent tracking session.
     *
     * Requires `ACCESS_FINE_LOCATION` or `ACCESS_COARSE_LOCATION` and device location to be enabled;
     * returns `false` otherwise.
     * This function will only start tracking if the SDK is enabled and not already tracking.
     * The track will continue until [stopTracking] is called or the maximum persistent
     * tracking interval is reached.
     *
     * In the new flow you could call [setTrackingMode] with [TrackingMode.Persistent]
     * and then call [startTracking]. After tracking ends, call [stopTracking]. Switch modes
     * explicitly with [setTrackingMode] when needed.
     *
     * Calling this method starts a single persistent tracking session without changing
     * the current [TrackingMode].
     *
     * @return `true` if the tracking session was successfully started, `false` otherwise (e.g., if the SDK is disabled or already tracking).
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @see setTrackingMode
     * @see getTrackingMode
     * @see startTracking
     * @see stopTracking
     */
    @Synchronized
    fun startTrackAsPersistent(): Boolean {
        checkInitialized()
        if (!ContextUtils.hasAnyLocationPermission(context) || !ContextUtils.isLocationEnabled(context)) {
            SdkLogger.sdkLogger?.warn(
                context, ModulesPrefixes.CORE, TAG,
                "called startTrackAsPersistent() ignored: location permission is missing or device location is disabled"
            )
            return false
        }
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called startTrackAsPersistent()")
        val sdkActive = delegate.isSdkActive()
        val isCurrentlyTracking = isTracking()
        if (sdkActive && !isCurrentlyTracking) {
            delegate.startTrackAsPersistent()
            return true
        } else {
            SdkLogger.sdkLogger?.warn(
                context, ModulesPrefixes.CORE, TAG, "called startTrackAsPersistent() ignored " +
                        "(isSdkEnabled=$sdkActive, isCurrentlyTracking=$isCurrentlyTracking)"
            )
        }
        return false
    }


    /**
     * Sets the maximum duration for a persistent tracking session.
     *
     * This function allows you to configure the maximum time, in minutes, that a
     * persistent tracking session will run before it is automatically stopped.
     * This serves as a safeguard to prevent indefinite tracking and conserve
     * device resources.
     *
     * The allowed interval is from 5 to 600 minutes (10 hours).
     * The default maximum duration is 240 minutes.
     *
     * @param minutes The maximum tracking duration in minutes.
     *                Must be in the range 5..600.
     * @throws IllegalArgumentException if [minutes] is outside the allowed range.
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @see startPersistentTracking
     */
    @Synchronized
    fun setMaxPersistentTrackingInterval(minutes: Int) {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called setMaxPersistentTrackingInterval($minutes)")
        delegate.setMaxPersistentTrackingInterval(minutes)
    }


    /**
     * Retrieves the maximum duration for a persistent tracking session.
     *
     * This function returns the time limit, in minutes, after which a persistent tracking
     * session started with [startPersistentTracking] will automatically stop.
     * The default value is 600 minutes (10 hours).
     *
     * @return The maximum interval in minutes for a persistent tracking session.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     *
     * @see startPersistentTracking
     * @see setMaxPersistentTrackingInterval
     */
    fun getMaxPersistentTrackingInterval(): Int {
        checkInitialized()
        return delegate.getMaxPersistentTrackingInterval()
    }

    /**
     * Sets the tracking mode used by the SDK for tracking sessions.
     *
     * Use this method to define whether tracking sessions started by SDK triggers
     * such as motion or location activity, or manually by [startTracking], should run
     * in [TrackingMode.Standard] or [TrackingMode.Persistent] mode. Persistent tracking
     * continues operating in the background and across app launches until explicitly
     * stopped or until the maximum persistent tracking interval is reached.
     *
     * Important: Using [TrackingMode.Persistent] may increase battery usage and
     * background activity. Ensure your app is configured with the required location
     * permissions, background modes, and usage descriptions.
     *
     * @param mode The tracking mode to apply for SDK-triggered and manually started tracking sessions.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     * @see getTrackingMode
     * @see setMaxPersistentTrackingInterval
     */
    @Synchronized
    fun setTrackingMode(mode: TrackingMode) {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called setTrackingMode($mode)")
        delegate.setTrackingMode(mode)
    }

    /**
     * Returns the tracking mode used by the SDK for tracking sessions.
     *
     * This value determines whether SDK-triggered tracking sessions and sessions started
     * manually with [startTracking] run in [TrackingMode.Standard] or
     * [TrackingMode.Persistent] mode. The default value is [TrackingMode.Standard].
     *
     * @return The current tracking mode for SDK-triggered and manually started tracking sessions.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     * @see setTrackingMode
     * @see setMaxPersistentTrackingInterval
     * @see getMaxPersistentTrackingInterval
     */
    fun getTrackingMode(): TrackingMode {
        checkInitialized()
        return delegate.getTrackingMode()
    }


    /**
     * Manually stops the current tracking session.
     *
     * This function will only stop tracking if the SDK is enabled and a tracking session is currently in progress.
     * If either of these conditions is not met, the call will be ignored and a warning will be logged.
     *
     * @return `true` if the tracking session was successfully stopped, `false` otherwise (e.g., if tracking was not active or the SDK was disabled).
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     *
     * @see getTrackingMode
     * @see setTrackingMode
     * @see isSdkEnabled
     * @see isTracking
     * @see startTracking
     */
    @Synchronized
    fun stopTracking(): Boolean {
        checkInitialized()
        SdkLogger.sdkLogger?.info(context, ModulesPrefixes.CORE, TAG, "called stopTracking()")
        val sdkEnabled = isSdkEnabled()
        val isCurrentlyTracking = isTracking()
        if (sdkEnabled && isCurrentlyTracking) {
            delegate.stopTracking()
            return true
        } else {
            SdkLogger.sdkLogger?.warn(
                context, ModulesPrefixes.CORE, TAG, "called stopTracking() ignored " +
                        "(isSdkEnabled=$sdkEnabled, isCurrentlyTracking=$isCurrentlyTracking)"
            )
        }
        return false
    }

    /**
     * Retrieves the start date and time of the current track recording.
     *
     * This function checks if a track is currently being recorded. If it is,
     * it returns the start time as a `Long` value representing the number of
     * milliseconds since the Unix epoch. If no track is currently being recorded,
     * it returns `null`.
     *
     * @return The start time of the current track in milliseconds since the epoch, or `null` if tracking is not active.
     * @see isTracking
     */
    @Synchronized
    fun getTrackStartDate(): Long? {
        checkInitialized()
        if (!isTracking()) {
            return null
        }
        return delegate.getTrackStartDate()
    }

    /**
     * Retrieves a paginated list of tracks from the local cache.
     *
     * This function allows filtering tracks by a date range. The start and end dates should be provided
     * in the format "yyyy-MM-dd'T'HH:mm:ss ZZ".
     *
     * @param locale The desired language for the track information. See [Locale].
     * @param startDate The start date for filtering tracks (inclusive), formatted as "yyyy-MM-dd'T'HH:mm:ss ZZ". Defaults to null (no start date filter).
     * @param endDate The end date for filtering tracks (inclusive), formatted as "yyyy-MM-dd'T'HH:mm:ss ZZ". Defaults to null (no end date filter).
     * @param offset The starting index for pagination.
     * @param limit The maximum number of tracks to return in a single page.
     * @return An array of [com.telematicssdk.tracking.server.model.sdk.Track] objects.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     */
    fun getTracks(
        locale: Locale,
        startDate: String? = null,
        endDate: String? = null,
        offset: Int,
        limit: Int
    ): Array<com.telematicssdk.tracking.server.model.sdk.Track> {
        checkInitialized()
        return delegate.getTracksCached(locale, startDate, endDate, offset, limit)
    }

    /**
     * Returns detailed track information (details are cached in local DB).
     *
     * @param locale  String Language in which track are to arrive. Maybe ru or en.
     * @param trackId  Track id.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     *
     */
    fun getTrackDetails(trackId: String, locale: Locale): TrackDetails {
        checkInitialized()
        return delegate.getTrackDetails(trackId, locale)
    }

    /**
     * Returns track tags.
     *
     * @param trackId  Track id.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun getTrackTags(trackId: String): Array<TrackTag> {
        checkInitialized()
        return delegate.getTrackTags(trackId)
    }

    /**
     * Add track tags. Return tags successfully added (with tag and type only, without source).
     *
     * @param trackId  Track id.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun addTrackTags(trackId: String, tags: Array<TrackTag>): Array<TrackTag> {
        checkInitialized()
        return delegate.addTrackTags(trackId, tags)
    }

    /**
     * Remove track tags. Return tags successfully removed (with tag and type only, without source).
     *
     * @param trackId  Track id.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun removeTrackTags(trackId: String, tags: Array<TrackTag>): Array<TrackTag> {
        checkInitialized()
        return delegate.removeTrackTags(trackId, tags)
    }

    /**
     * Returns unused tracks information
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     *
     */
    @Deprecated(
        message = "we are going to replace with getUnsentTrips",
        replaceWith = ReplaceWith(expression = "getUnsentTrips()")
    )
    fun getUnsentTracks(): Array<Track> {
        return getUnsentTrips()
    }

    /**
     * Returns unused trips information
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     *
     */
    fun getUnsentTrips(): Array<Track> {
        checkInitialized()
        return delegate.getUnsentTracksMainSafe()
    }

    /**
     * Retrieves the number of locally stored tracks that have not yet been sent to the server.
     *
     * This function is deprecated. Use [getUnsentTripCount] instead.
     *
     * @return The count of unsent tracks.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     * @see getUnsentTripCount
     * @see getUnsentTrips
     * @see uploadUnsentTrips
     * @deprecated Use [getUnsentTripCount] as "track" is being renamed to "trip" across the SDK.
     */
    @Deprecated(
        message = "we are going to replace with getUnsentTripCount",
        replaceWith = ReplaceWith(expression = "getUnsentTripCount()")
    )
    fun getUnsentTracksCount(): Int {
        return getUnsentTripCount()
    }

    /**
     * Gets the number of locally stored trips that have not yet been sent to the server.
     *
     * This can be useful for displaying an indicator to the user or for debugging purposes.
     *
     * @return The count of unsent trips.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     *
     * @see getUnsentTrips
     * @see uploadUnsentTrips
     */
    fun getUnsentTripCount(): Int {
        checkInitialized()
        return delegate.getUnsentTracksCountMainSafe()
    }

    /**
     * Returns the number of persisted heartbeats awaiting queue processing across all accounts.
     * Includes rows for previous accounts and invalid tokens until normal queue processing removes
     * them. Heartbeats queued in memory but not yet persisted are not included.
     *
     * This performs a synchronous database COUNT and may block. Main-thread calls run the read on
     * the SDK's background executor and wait for the result. Read failures return zero, matching
     * [getUnsentTripCount]. This read does not send network requests, enqueue heartbeats, or wait
     * for the SDK handler queue.
     * The count and [getLastHeartbeatsSyncDate] are independent snapshots and can change between reads.
     *
     * @return The entire persisted heartbeat queue count, or zero if empty or the read fails.
     * @throws IllegalStateException if the SDK is not initialized.
     */
    @AnyThread
    fun getHeartbeatsCount(): Int {
        checkInitialized()
        return delegate.getHeartbeatsCount()
    }

    /**
     * Returns the date of the last successful heartbeat batch upload, or null if none has succeeded.
     * The date is shared across accounts and persists across SDK restarts until app data is cleared.
     * It is updated after a successful heartbeat API response and stored asynchronously.
     *
     * May be called on any thread. This reads preferences without accessing the heartbeat database,
     * sending network requests, or enqueueing heartbeats.
     *
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     */
    @AnyThread
    fun getLastHeartbeatsSyncDate(): Date? {
        checkInitialized()
        return delegate.getLastHeartbeatsSyncDate()
    }


    /**
     * Manually triggers the upload of all locally stored trips that have not yet been sent to the server.
     *
     * This is useful for forcing a synchronization with the backend, for example, when a stable
     * network connection becomes available. The SDK automatically attempts to upload trips in the background,
     * but this method provides a way to initiate the process on demand.
     *
     * The number of trips pending upload can be checked with [getUnsentTripCount].
     *
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     *
     * @see getUnsentTripCount
     * @see getUnsentTrips
     */
    fun uploadUnsentTrips() {
        checkInitialized()
        return delegate.uploadUnsentTracks()
    }

    /**
     * Retrieves a dictionary of available track types.
     *
     * This dictionary can be used to understand the possible categories a track can be assigned to,
     * such as "business" or "personal". The retrieved information can then be used with
     * the [changeTrackOrigin] method to reclassify a specific track.
     *
     * @param dictionaryLocale The locale ([Locale]) for the dictionary's display names (e.g., "en", "ru").
     * @return An array of [TrackOriginDictionary] objects, each representing a possible track type.
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     * @see changeTrackOrigin
     */
    fun getTrackOriginDict(dictionaryLocale: Locale): Array<TrackOriginDictionary> {
        checkInitialized()
        return delegate.getTrackOriginDict(dictionaryLocale)
    }

    /**
     * Method allows you to change the type of track to a type from the dictionary.
     * Returns true if operation was successful and false otherwise
     * See also [getTrackOriginDict].
     *
     * @param trackToken Track Id
     * @param newCode    New track type code from track origin dictionary.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     * @throws IOException if failed or interrupted I/O operation (No Internet connection, etc.).
     */
    @Throws(IllegalStateException::class, IOException::class)
    fun changeTrackOrigin(trackToken: String, newCode: String): Boolean {
        checkInitialized()
        return delegate.changeTrackOrigin(trackToken, newCode)
    }

    /**
     * Provides general scoring information about key driving parameters such as mileage, maneuvers, and speeding.
     *
     * This function is deprecated and will be removed in a future version.
     * Use [getMainStatistics] instead for retrieving dashboard information.
     *
     * @param trackTag An optional filter to return data only for a specific track tag.
     * @return A [DashboardInfo] object containing the scoring data.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     * @see getMainStatistics
     * @deprecated Use [getMainStatistics] instead. This function will be removed in a future release.
     */
    @Deprecated(message = "use getMainStatistics(trackTag: String), will be removed in 2021")
    fun getDashboardInfo(trackTag: String? = null): DashboardInfo {
        return getMainStatistics(trackTag)
    }

    /**
     * Retrieves the main statistics for the dashboard, which can be optionally filtered by a track tag.
     *
     * This function provides access to core driving statistics, such as mileage, maneuvers, and speeding information,
     * which are essential for displaying a summary or dashboard view. The data can be narrowed down to a
     * specific set of trips by providing a `trackTag`.
     *
     * @param trackTag An optional string used to filter the statistics. If provided, the function will
     *   return statistics only for tracks that have been tagged with this value. If `null`, statistics for
     *   all tracks are returned.
     * @return A [DashboardInfo] object containing the main dashboard statistics.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     *
     * @see DashboardInfo
     * @see getDrivingDetailsStatistics
     * @see addTrackTags
     */
    fun getMainStatistics(trackTag: String? = null): DashboardInfo {
        checkInitialized()
        return delegate.getDashboardInfo(trackTag)
    }

    /**
     * Represents details info about Driving scoring.
     *
     * @param period  Statistics period. See also [StatisticPeriod].
     * @param trackTag filter returned data by track tag, optional
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun getDrivingDetailsStatistics(
        period: StatisticPeriod,
        trackTag: String? = null
    ): DrivingDetails {
        checkInitialized()
        return delegate.getDrivingDetailsStatistics(period, trackTag)
    }

    /**
     * Represents details info about Driving Time scoring.
     *
     * @param period  Statistics period. See also [StatisticPeriod].
     * @param trackTag filter returned data by track tag, optional
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun getDrivingTimeDetailsStatistics(
        period: StatisticPeriod,
        trackTag: String? = null
    ): DrivingTimeDetails {
        checkInitialized()
        return delegate.getDrivingTimeDetailsStatistics(period, trackTag)
    }

    /**
     * Represents details info about Speed detail scoring.
     *
     * @param period  Statistics period. See also [StatisticPeriod].
     * @param trackTag filter returned data by track tag, optional
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun getSpeedDetailStatistics(period: StatisticPeriod, trackTag: String? = null): SpeedDetails {
        checkInitialized()
        return delegate.getSpeedDetailsStatistics(period, trackTag)
    }

    /**
     * Represents details info about Mileage scoring.
     *
     * @param period  Statistics period. See also [StatisticPeriod].
     * @param trackTag filter returned data by track tag, optional
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun getMileageDetailsStatistics(
        period: StatisticPeriod,
        trackTag: String? = null
    ): MileageDetails {
        checkInitialized()
        return delegate.getMileageDetailsStatistics(period, trackTag)
    }

    /**
     * Represents details info about Phone scoring.
     *
     * @param period  Statistics period. See also [StatisticPeriod].
     * @param trackTag filter returned data by track tag, optional
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     */
    fun getPhoneDetailStatistics(period: StatisticPeriod, trackTag: String? = null): PhoneDetails {
        checkInitialized()
        return delegate.getPhoneUsageDetailsStatistics(period, trackTag)
    }

    /**
     * Register tracking state listener
     *
     * SDK invokes this listener on the app main thread.
     *
     * @param listener Track state change listener
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     * @return true if listener registered
     */
    @Synchronized
    fun registerCallback(listener: TrackingStateListener): Boolean {
        checkInitialized()
        return delegate.registerCallback(listener)
    }

    /**
     * Unregister tracking state listener
     *
     * @param listener
     * @return true if listener unregistered
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    @Synchronized
    fun unregisterCallback(listener: TrackingStateListener): Boolean {
        checkInitialized()
        return delegate.unregisterCallback(listener)
    }

    /**
     * Register speed violations listener
     *
     * SDK invokes this listener on the app main thread.
     *
     * @param listener Speed violations
     * @param speedLimitKmH speed limit in km per hour, must me >=1
     * @param speedLimitTimeoutMs the time we give for driver to reduce speed before throwing violation, must be >= 1000
     * @return true if listener registered
     * @throws IllegalArgumentException if speedLimitKmH < 1
     * @throws IllegalArgumentException if speedLimitTimeoutMs < 1000
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    @Synchronized
    fun registerSpeedViolations(
        speedLimitKmH: Float,
        speedLimitTimeoutMs: Long,
        listener: SpeedViolationsListener
    ): Boolean {
        checkInitialized()
        if (speedLimitKmH < 1F) {
            throw IllegalArgumentException("speedLimitKmH($speedLimitKmH) must be >= 1")
        }
        if (speedLimitTimeoutMs < 1000L) {
            throw IllegalArgumentException("speedLimitTimeoutMs($speedLimitTimeoutMs) must be >= 1000")
        }
        return delegate.registerSpeedViolationsCallback(
            listener,
            speedLimitKmH,
            speedLimitTimeoutMs
        )
    }

    /**
     * Unregister speed violations listener
     *
     * @return true if listener unregistered
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    @Synchronized
    fun unregisterSpeedViolations(): Boolean {
        checkInitialized()
        return delegate.unregisterSpeedViolationCallback()
    }

    /**
     * Checks if any speed violations have been registered.
     *
     * This function delegates the check to an internal component (`delegate`).
     *
     * @return `true` if any speed violations have been registered, `false` otherwise.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    @Synchronized
    fun isSpeedViolationsRegistered(): Boolean {
        checkInitialized()
        return delegate.isSpeedViolationsRegistered()
    }

    /**
     * Set speed limit
     *
     * @param speedLimitKmH speed limit in km per hour, must me >=1
     * @throws IllegalArgumentException if speedLimitKmH < 1
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    fun setSpeedLimit(speedLimitKmH: Float) {
        checkInitialized()
        if (speedLimitKmH < 1F) {
            throw IllegalArgumentException("speedLimitKmH($speedLimitKmH) must be >= 1")
        }
        return delegate.setSpeedLimit(speedLimitKmH)
    }

    /**
     * Set speed limit timeout
     *
     * @param speedLimitTimeoutMs the time we give for driver to reduce speed before throwing violation, must be >= 1000
     * @throws IllegalArgumentException if speedLimitTimeoutMs < 1000
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    fun setSpeedLimitTimeout(speedLimitTimeoutMs: Long) {
        checkInitialized()
        if (speedLimitTimeoutMs < 1000L) {
            throw IllegalArgumentException("speedLimitTimeoutMs($speedLimitTimeoutMs) must be >= 1000")
        }
        return delegate.setSpeedLimitTimeouts(speedLimitTimeoutMs)
    }

    /**
     * Retrieves the current speed limit.
     *
     * This function delegates the task of retrieving the speed limit to an internal delegate.
     *
     * @return The speed limit as a floating-point number.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    fun getSpeedLimit(): Float {
        checkInitialized()
        return delegate.getSpeedLimit()
    }

    /**
     * Retrieves the timeout value associated with speed limiting.
     *
     * This function delegates to an internal object (`delegate`) that
     * manages the speed limit configuration. It returns the timeout
     * value, which represents the duration a process or operation
     * should wait before exceeding the configured speed limit.
     *
     * @return A [Long] representing the timeout in milliseconds.
     * @throws IllegalStateException if [initialize] never called. See also [isInitialized].
     */
    fun getTimeouts(): Long {
        checkInitialized()
        return delegate.getSpeedLimitTimeout()
    }


    /**
     * Checks if Real-Time Data (RTD) is enabled.
     *
     * This function queries the internal `delegate` to determine if the RTD feature is currently active.
     * It also logs the result for debugging purposes.
     *
     * @return `true` if RTD is enabled, `false` otherwise.
     * @throws IllegalStateException if the SDK has not been initialized.
     *
     */
    fun isRtdEnabled(): Boolean {
        checkInitialized()
        val isRtdEnabled = delegate.isRtdEnabled()
        SdkLogger.sdkLogger?.info(
            context,
            ModulesPrefixes.CORE,
            TAG,
            "called isRtdEnabled() return $isRtdEnabled"
        )
        return isRtdEnabled
    }

    /**
     * Sets a listener to receive location updates.
     *
     * This listener will be invoked whenever a new location is detected by the SDK.
     * SDK invokes this listener on the app main thread.
     * To stop receiving updates and prevent memory leaks, call this method again with `null`.
     *
     * @param listener The listener for location updates. Pass `null` to remove the currently registered listener.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     */
    @Synchronized
    fun setLocationListener(listener: LocationListener? = null) {
        checkInitialized()
        delegate.setLocationListener(listener)
    }

    /**
     * Retrieves the currently registered [LocationListener].
     *
     * This function returns the listener that was previously set using [setLocationListener].
     * If no listener has been registered, it will return `null`.
     *
     * @return The current [LocationListener] instance, or `null` if none is set.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     * @see setLocationListener
     */
    @Synchronized
    fun getLocationListener(): LocationListener? {
        checkInitialized()
        return delegate.getLocationListener()
    }

    /**
     * Registers a broadcast receiver to receive callbacks about SDK events.
     *
     * This method allows you to receive key SDK events (like tracking status, location updates, etc.)
     * via a `BroadcastReceiver`. This is useful for handling events even when your app is in the
     * background, as it doesn't require maintaining a direct listener object in memory.
     *
     * The provided receiver class must extend [TrackingEventsReceiver] to correctly handle the
     * incoming intents.
     * SDK invokes receiver callbacks on the app main thread.
     *
     * The following events can be received:
     * - [TrackingEventsReceiver.onLocationChanged]
     * - [TrackingEventsReceiver.onStartTracking]
     * - [TrackingEventsReceiver.onStopTracking]
     * - [TrackingEventsReceiver.onSpeedViolation]
     * - [TrackingEventsReceiver.onNewEvents]
     * - [TrackingEventsReceiver.onSdkDeprecated]
     *
     * Don't forget to call [unregisterTrackingEventsReceiver] when the receiver is no longer needed
     * to prevent resource leaks.
     *
     * @param receiver The `Class` of your broadcast receiver, which must be a subclass of [TrackingEventsReceiver].
     * @throws IllegalStateException if [initialize] was never called. See [isInitialized].
     * @see unregisterTrackingEventsReceiver
     * @see TrackingEventsReceiver
     */
    @Synchronized
    fun registerTrackingEventsReceiver(receiver: Class<*>) {
        checkInitialized()
        delegate.registerTrackingEventsReceiver(receiver)
    }

    /**
     * Unregisters the broadcast receiver for SDK events.
     *
     * This method stops the app from receiving callbacks about SDK events that were previously
     * registered using [registerTrackingEventsReceiver].
     *
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     * @see registerTrackingEventsReceiver
     * @see TrackingEventsReceiver
     */
    @Synchronized
    fun unregisterTrackingEventsReceiver() {
        checkInitialized()
        delegate.unregisterTrackingEventsReceiver()
    }

    /**
     * Shares or unshares a track and returns the result of the operation.
     *
     * This function allows changing the sharing status of a specific track.
     * The operation is performed via a network request.
     *
     * @param trackToken The unique identifier for the track to be shared or unshared.
     * @param isShared `true` to make the track public, `false` to make it private.
     * @return `true` if the sharing status was updated successfully, `false` otherwise.
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     * @throws IOException if a network error occurs (e.g., no internet connection).
     */
    fun shareTrack(trackToken: String, isShared: Boolean): Boolean {
        checkInitialized()
        return delegate.shareTrack(trackToken, isShared)
    }

    /**
     * Retrieves the details for a track that has been shared.
     *
     * This function fetches information about a specific track using its unique `trackToken`.
     * It is intended to be used to view the details of a track that has been made public via the [shareTrack] function.
     * This operation requires an internet connection, as it communicates with the server.
     *
     * @param trackToken The unique identifier of the shared track.
     * @return A [TrackDetails] object containing the detailed information of the track.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     * @throws IllegalArgumentException if Device ID is not valid GUID. See [isDeviceIdValid].
     * @throws IOException if the operation fails due to network issues, such as no internet connection.
     * @see shareTrack
     */
    fun getSharedTrackDetails(trackToken: String): TrackDetails {
        checkInitialized()
        return delegate.getSharedTrackDetails(trackToken)
    }

    /**
     * Asynchronously retrieves the list of tags that can be assigned to future tracks.
     *
     * These tags are fetched from the server and can be used to categorize upcoming driving sessions.
     * The result of this operation is delivered through a registered [TagsProcessingListener] or [TagsProcessingReceiver].
     *
     * @deprecated Future track tags are deprecated. Use [getProperties] instead.
     *
     * @see getProperties
     * @see addTagsProcessingCallback
     * @see registerTagsReceiver
     * @see addFutureTrackTag
     * @see removeFutureTrackTag
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use getProperties() instead.",
        replaceWith = ReplaceWith(expression = "getProperties()")
    )
    fun getFutureTrackTags() {
        checkInitialized()
        delegate.getTags()
    }

    /**
     * Creates a new tag that will be assigned to the next recorded track.
     *
     * This function allows you to pre-define tags that will be automatically associated with
     * the subsequent tracking session. For example, you could use this to categorize a future
     * trip as "business" or "personal".
     *
     * The result of this operation is delivered asynchronously. To receive updates,
     * you must register a [TagsProcessingListener] using [addTagsProcessingCallback]
     * or a [TagsProcessingReceiver] using [registerTagsReceiver].
     *
     * @param tag The name of the tag to create (e.g., "work", "vacation").
     * @param source An optional string to specify the origin or creator of the tag (e.g., "user", "app").
     * @throws IllegalStateException if [initialize] was never called. See [isInitialized].
     * @deprecated Future track tags are deprecated. Use [setProperties] instead.
     *
     * @see setProperties
     * @see getFutureTrackTags
     * @see removeFutureTrackTag
     * @see addTagsProcessingCallback
     * @see registerTagsReceiver
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use setProperties(properties) instead."
    )
    fun addFutureTrackTag(tag: String?, source: String? = null) {
        checkInitialized()
        delegate.addTag(tag, source)
    }

    /**
     * Removes a tag that will be automatically added to future tracks.
     *
     * This function schedules a tag for removal. Once removed, it will no longer be
     * automatically associated with new tracks created after this operation.
     *
     * The result of the tag removal operation is communicated asynchronously.
     * You can listen for the outcome by registering a [TagsProcessingListener]
     * using [addTagsProcessingCallback] or by setting up a [TagsProcessingReceiver]
     * via [registerTagsReceiver].
     *
     * @param tag The name of the tag to remove. If the tag does not exist, the operation will be ignored.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     *
     * @deprecated Future track tags are deprecated. Use [setProperties] with an updated map
     * or [clearProperties] instead.
     *
     * @see setProperties
     * @see clearProperties
     * @see addFutureTrackTag
     * @see getFutureTrackTags
     * @see removeAllFutureTrackTags
     * @see addTagsProcessingCallback
     * @see registerTagsReceiver
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use setProperties(properties) or clearProperties() instead."
    )
    fun removeFutureTrackTag(tag: String?) {
        checkInitialized()
        delegate.removeTag(tag)
    }

    /**
     * Removes all tags that are scheduled to be added to future tracks.
     *
     * This operation is asynchronous. The result can be obtained by registering a
     * [TagsProcessingListener] or a [TagsProcessingReceiver].
     *
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     *
     * @deprecated Future track tags are deprecated. Use [clearProperties] instead.
     *
     * @see clearProperties
     * @see registerTagsReceiver
     * @see addTagsProcessingCallback
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use clearProperties() instead.",
        replaceWith = ReplaceWith(expression = "clearProperties()")
    )
    fun removeAllFutureTrackTags() {
        checkInitialized()
        delegate.removeAllTags()
    }

    /**
     * Disables the SDK after all pending trips have been successfully uploaded.
     *
     * This function initiates a graceful shutdown of the SDK. It stops accepting new tracking data
     * but waits for any ongoing trip uploads to complete before fully deactivating.
     * This ensures no data is lost when disabling the SDK.
     *
     * To check if the SDK is in the process of shutting down after calling this method,
     * use [isSdkDisablePending].
     *
     * @throws IllegalStateException if [initialize] has not been called.
     * @see setEnableSdk
     * @see isSdkDisablePending
     * @deprecated This function is deprecated. Use `setEnableSdk(false)` instead for the same behavior.
     */

    @Deprecated(
        message = "Please use setEnableSdk(false)",
        replaceWith = ReplaceWith(expression = "setEnableSdk(false)")
    )
    fun setDisableWithUpload() {
        checkInitialized()
        delegate.disableSdkOnUploadComplete()
    }

    /**
     * Sends a custom heartbeat signal to the backend with a specified reason.
     *
     * This function can be used to manually trigger a data synchronization event,
     * which can be useful for debugging or forcing an update under specific conditions.
     * The `reason` parameter allows for categorizing why the heartbeat was sent,
     * which can be helpful for analysis on the backend.
     *
     * @param reason A string describing the reason for sending the custom heartbeat.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     */
    fun sendCustomHeartbeats(reason: String) {
        checkInitialized()
        delegate.sendCustomHeartbeats(reason)
    }


    /**
     * Registers a broadcast receiver to receive callbacks about future track tag processing.
     *
     * This method allows the app to be notified about the results of asynchronous tag operations
     * (like `getFutureTrackTags`, `addFutureTrackTag`, etc.) via a `BroadcastReceiver`.
     * The receiver will be invoked when tags are added, removed, or fetched.
     * SDK invokes receiver callbacks on the app main thread.
     *
     * The provided `receiver` class must inherit from [TagsProcessingReceiver] to handle the specific tag-related intents.
     *
     * Example of a receiver implementation:
     * ```kotlin
     * class MyTagsReceiver : TagsProcessingReceiver() {
     *     override fun onGetTags(context: Context, intent: Intent, tags: Array<String>?) {
     *         // Handle received tags
     *     }
     *
     *     override fun onTagAdd(context: Context, intent: Intent) {
     *         // Handle tag addition confirmation
     *     }
     *
     *     override fun onTagRemove(context: Context, intent: Intent) {
     *         // Handle tag removal confirmation
     *     }
     *
     *     override fun onAllTagsRemove(context: Context, intent: Intent) {
     *         // Handle all tags removed confirmation
     *     }
     * }
     * ```
     *
     * To register this receiver, call:
     * `TrackingApi.getInstance().registerTagsReceiver(MyTagsReceiver::class.java)`
     *
     * It is important to unregister the receiver when it's no longer needed to prevent memory leaks,
     * typically in `onDestroy()` or a similar lifecycle method, using [unregisterTagsReceiver].
     *
     * For a non-broadcast, in-process callback mechanism, see [addTagsProcessingCallback].
     *
     * @deprecated Future track tags are deprecated. Use Properties APIs instead:
     * [setProperties], [getProperties], and [clearProperties]. Properties operations are
     * synchronous and do not use tag processing receivers.
     *
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use Properties APIs instead."
    )
    @Synchronized
    fun registerTagsReceiver(receiver: Class<*>) {
        checkInitialized()
        delegate.registerTagsReceiver(receiver)
    }

    /**
     * Unregisters the broadcast receiver for tag processing events.
     *
     * This function removes a previously registered `BroadcastReceiver` that listens for callbacks related to tag processing,
     * such as when tags are added, removed, or retrieved.
     *
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     *
     * @see registerTagsReceiver
     * @see TagsProcessingReceiver
     * @deprecated Future track tags are deprecated. Use Properties APIs instead.
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use Properties APIs instead."
    )
    @Synchronized
    fun unregisterTagsReceiver() {
        checkInitialized()
        delegate.unregisterTagsReceiver()
    }

    /**
     * Adds a listener to receive callbacks about tags processing.
     *
     * This function registers a [TagsProcessingListener] that will be invoked when tag-related
     * operations complete, such as adding, removing, or retrieving tags for future tracks.
     *
     * The results of operations like [getFutureTrackTags], [addFutureTrackTag], and [removeFutureTrackTag]
     * are delivered asynchronously through this listener.
     * SDK invokes this listener on the app main thread.
     *
     * **Important:** To prevent memory leaks, you must unregister the listener when it is no longer
     * needed by calling [removeTagsProcessingCallback].
     *
     * @param callback The [TagsProcessingListener] instance to register.
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @see removeTagsProcessingCallback
     * @see getFutureTrackTags
     * @see addFutureTrackTag
     * @see removeFutureTrackTag
     * @see TagsProcessingListener
     * @deprecated Future track tags are deprecated. Use Properties APIs instead:
     * [setProperties], [getProperties], and [clearProperties]. Properties operations are
     * synchronous and do not use tag processing callbacks.
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use Properties APIs instead."
    )
    @Synchronized
    fun addTagsProcessingCallback(callback: TagsProcessingListener) {
        checkInitialized()
        delegate.addTagsProcessingCallback(callback)
    }

    /**
     * Removes the currently registered [TagsProcessingListener].
     * After calling this, the app will no longer receive callbacks for tag processing events
     * through the listener interface. This is important to call to prevent memory leaks,
     * for example, in a lifecycle-aware component's `onDestroy` or `onStop` method.
     *
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @see addTagsProcessingCallback
     * @see TagsProcessingListener
     * @deprecated Future track tags are deprecated. Use Properties APIs instead.
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use Properties APIs instead."
    )
    @Synchronized
    fun removeTagsProcessingCallback() {
        checkInitialized()
        delegate.removeTagsProcessingCallback()
    }

    /**
     * Retrieves the currently registered tags processing listener.
     *
     * This function returns the [TagsProcessingListener] instance that was previously set
     * using [addTagsProcessingCallback]. If no listener has been registered, or if it has been
     * removed, this function will return `null`.
     *
     * @return The currently registered [TagsProcessingListener], or `null` if none is registered.
     * @throws IllegalStateException if the SDK has not been initialized. See [initialize].
     * @see addTagsProcessingCallback
     * @see removeTagsProcessingCallback
     * @deprecated Future track tags are deprecated. Use Properties APIs instead.
     */
    @Deprecated(
        message = "Future track tags are deprecated. Use Properties APIs instead."
    )
    @Synchronized
    fun getTagsProcessingCallback(): TagsProcessingListener? {
        checkInitialized()
        return delegate.getTagsProcessingCallback()
    }

    /**
     * Sets the `Intent` to be launched when the user taps on the main SDK notification.
     * This allows you to specify which `Activity` should be opened, providing a seamless
     * user experience. The notification is shown while the SDK is actively tracking.
     *
     * @param intent The `Intent` to associate with the notification click.
     * @throws IllegalStateException if [initialize] was never called. See also [isInitialized].
     * @see clearIntentForNotification
     */
    @Synchronized
    fun setIntentForNotification(intent: Intent) {
        checkInitialized()
        delegate.setIntentForNotification(intent)
    }

    /**
     * Clears the custom [Intent] for the main SDK notification.
     *
     * When an `Intent` is cleared, tapping the notification will no longer start a custom activity.
     * Instead, it will revert to the default behavior, which is to do nothing.
     *
     * @throws IllegalStateException if [initialize] has not been called. See [isInitialized].
     * @see setIntentForNotification
     */
    @Synchronized
    fun clearIntentForNotification() {
        checkInitialized()
        delegate.clearIntentForNotification()
    }

    /**
     * Sets the accident detection sensitivity level.
     *
     * This function allows you to configure the sensitivity of the accident detection feature
     * by choosing from a set of predefined presets. It ensures that the SDK has been
     * initialized before saving the new setting. Changes apply to subsequent accident checks.
     *
     * @param sensitivity The desired sensitivity level from the [AccidentDetectionSensitivity] enum.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @see getAccidentDetectionSettings
     * @see resetAccidentDetectionSettings
     * @see AccidentDetectionSensitivity
     */
    @Synchronized
    fun setAccidentDetectionMode(sensitivity: AccidentDetectionSensitivity) {
        checkInitialized()
        delegate.setAccidentDetectionSettings(sensitivity.preset)
    }

    /**
     * Retrieves the current accident detection settings.
     *
     * This function returns the currently configured sensitivity.
     * The settings can be modified using [setAccidentDetectionMode].
     *
     * @return An [AccidentDetectionSettings] object containing the saved settings.
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     *
     * @see setAccidentDetectionMode
     * @see resetAccidentDetectionSettings
     */
    fun getAccidentDetectionSettings(): AccidentDetectionSettings {
        checkInitialized()
        return delegate.getAccidentDetectionSettings()
    }

    /**
     * Resets the accident detection settings to their default values.
     *
     * The SDK uses the default settings for subsequent accident checks.
     *
     * This is a synchronized function to ensure thread-safe modifications.
     *
     * @throws IllegalStateException if the SDK has not been initialized. Call [initialize] first.
     *
     * @see setAccidentDetectionMode
     * @see getAccidentDetectionSettings
     */
    @Synchronized
    fun resetAccidentDetectionSettings() {
        checkInitialized()
        delegate.resetAccidentDetectionSettings()
    }


    /**
     * Checks if passive detection (aggressive tracking mode) is enabled.
     *
     * When enabled, the SDK listens for passive location updates to improve trip detection
     * reliability.
     *
     * @return `true` if passive detection is enabled, `false` otherwise.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @see setPassiveDetectionEnabled
     */
    fun isPassiveDetectionEnabled(): Boolean {
        checkInitialized()
        return delegate.isPassiveDetectionEnabled()
    }

    /**
     * Enables or disables aggressive tracking mode.
     *
     * When enabled, the SDK uses an extra [LocationDetector] that listens for passive
     * location updates. If a significant displacement is detected, it triggers a
     * high-accuracy GPS check to confirm the start of a trip. This improves detection
     * reliability but may have a minor impact on battery consumption.
     *
     * @param enabled `true` to enable aggressive tracking, `false` to disable it.
     * @throws IllegalStateException if the SDK has not been initialized.
     */
    @Synchronized
    fun setPassiveDetectionEnabled(enabled: Boolean) {
        checkInitialized()
        delegate.setPassiveDetectionEnabled(enabled)
    }

    /**
     * Retrieves the current SDK version as a string.
     *
     * The version string is constructed by combining the version name (`VERSION_NAME`)
     * and version build (`VERSION_BUILD`) defined in the [BuildConfig].
     *
     * @return A string representing the SDK version (e.g., "1.2.3.45").
     */
    fun getSdkVersion() = "${BuildConfig.VERSION_NAME}.${BuildConfig.VERSION_BUILD}"


    /**
     * Retrieves the internal SDK handler queue.
     *
     * This function is for internal use only and provides access to the underlying `SdkHandlerQueue`
     * that manages asynchronous tasks within the SDK. It first ensures the SDK is initialized
     * before returning the queue instance from the delegate.
     *
     * @return The [SdkHandlerQueue] instance.
     * @throws IllegalStateException if the SDK has not been initialized.
     * @suppress For internal use only.
     */
    internal fun getQueue(): SdkHandlerQueue {
        checkInitialized()
        return delegate.queue
    }

    /**
     * Checks if all required runtime permissions for the SDK are granted.
     *
     * This function verifies the following permissions:
     * - `ACCESS_FINE_LOCATION` (always required).
     * - `ACCESS_BACKGROUND_LOCATION` and `ACTIVITY_RECOGNITION` (on Android Q and newer).
     *
     * If any of the required permissions are not granted, this function will throw an exception.
     *
     * @throws IllegalStateException if one or more required permissions are not granted. The exception message lists the missing permissions.
     */
    private fun checkGrantedPermissions() {
        val requiredPermissions = arrayListOf(Manifest.permission.ACCESS_FINE_LOCATION)

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
            requiredPermissions.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            requiredPermissions.add(Manifest.permission.ACTIVITY_RECOGNITION)
        }

        val result = ContextUtils.checkPermissions(
            context, *requiredPermissions.toTypedArray()
        )
        // check any of permission is not granted
        val notGrantedPermissions = result.filter { !it.second }
        if (notGrantedPermissions.isNotEmpty()) {
            val errorMessage = StringBuilder("Runtime permissions must be granted: ").apply {
                notGrantedPermissions.forEach {
                    append(it.first)
                    if (notGrantedPermissions.lastIndexOf(it) < notGrantedPermissions.size - 1) {
                        append(", ")
                    } else {
                        append(".")
                    }
                }
            }.toString()
            throw IllegalStateException(errorMessage)
        }
    }

    /**
     * Checks if the SDK has been initialized.
     *
     * This is a private helper method used by public-facing functions to ensure that
     * the SDK has been properly set up via the [initialize] method before any other
     * operations are attempted.
     *
     * @throws IllegalStateException if the SDK has not been initialized.
     */
    private fun checkInitialized() {
        if (!isInitialized) {
            throw IllegalStateException("SDK not initialized. You need to call initialize(Context) method before")
        }
    }

    /**
     * Checks if the provided [Context] is null.
     *
     * This is a private helper function used to validate the context passed to other public methods,
     * ensuring that the SDK does not attempt to operate with a null context.
     *
     * @param context The [Context] to check.
     * @throws IllegalArgumentException if the `context` is null.
     */
    private fun checkNotNullContext(context: Context?) {
        if (context == null) {
            throw IllegalArgumentException("Context must not be null")
        }
    }

    /**
     * Validates the provided SDK settings.
     *
     * This function checks if the values within the [Settings] object are valid. Specifically, it ensures that:
     * - `accuracy` is not negative.
     * - `stopTrackingTimeout` is not negative.
     *
     * If any of these conditions are not met, it throws an [IllegalArgumentException] with a descriptive message.
     *
     * @param settings The [Settings] object to validate.
     * @throws IllegalArgumentException if any of the settings values are invalid.
     */
    private fun checkSettings(settings: Settings) {
        if (settings.accuracy < 0) {
            throw IllegalArgumentException("Settings.accuracy(" + settings.accuracy + ") must be >= 0")
        }
        if (settings.stopTrackingTimeout < 0) {
            throw IllegalArgumentException("Settings.stopTrackingTimeout(" + settings.stopTrackingTimeout + ") must be >= 0")
        }
    }
}

package com.telematicssdk.tracking.server.model.sdk

data class SpeedDetails(
    /**
     * Speeding score
     * Range 0...100
     */
    var speedRating: Int = 0,  //Рейтинг скорости

    /**
     * Above speed limit per 100 km in km
     */
    var drivingOverSpeedLimitFor100Km: Float = 0.toFloat(), //Превышение скорости на 100 км пути

    /**
     * Above speed limit more than 20km/h per 100 km in km
     */
    var drivingOverSpeedLimitMore20KmFor100Km: Float = 0.toFloat(), //Превышение скорости более 20км...

    /**
     * Max Speed in km/h
     */
    var maximumSpeed: Int = 0,

    /**
     * Average Speed in km/h
     */
    var averageSpeed: Int = 0,

    /**
     * Speeding in km/h
     */
    var drivingOverSpeedLimitDiagram: Array<DiagramEntity>? = null,

    /**
     * Speeding over 20km/h in km/h
     */
    var drivingOverSpeedLimitMore20KmDiagram: Array<DiagramEntity>? = null
)
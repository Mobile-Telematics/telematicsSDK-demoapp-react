package com.telematicssdk.tracking.server.model.sdk

class TrackTag(
    /**
     * Tag name.
     */
    var tag: String,
    /**
     * Source. For ex. App module (optional)
     */
    var source: String? = null
) {

    /**
     * Source type. Maybe: "Sdk", "UserApp".
     */
    var type: String? = null
        internal set

    internal constructor(
        tag: String,
        type: String,
        source: String?
    ) : this(tag, source) {
        this.tag = tag
        this.type = type
        this.source = source
    }

    override fun toString(): String {
        return "TrackTag(tag=$tag, type=$type, source=$source)"
//                return "TrackTag(tag=$tag, source=$source)"
    }
}
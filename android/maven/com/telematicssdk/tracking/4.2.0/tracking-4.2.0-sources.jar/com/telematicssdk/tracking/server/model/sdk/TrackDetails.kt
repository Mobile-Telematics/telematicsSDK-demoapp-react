package com.telematicssdk.tracking.server.model.sdk

data class TrackDetails(
    /**
     * The start address.
     */
    val addressStart: String?,

    /**
     * The end address.
     */
    val addressEnd: String?,


    /**
     * The end date in "yyyy-MM-dd'T'HH:mm:ss ZZ" format.
     */
    val endDate: String?,

    /**
     * The start date in "yyyy-MM-dd'T'HH:mm:ss ZZ" format.
     */
    val startDate: String?,

    /**
     * The unique trip id.
     */
    val trackId: String?,

    /**
     * The count of sharp acceleration.
     */
    val accelerationCount: Int = 0,

    /**
     * The count of sharp braking.
     */
    val decelerationCount: Int = 0,

    /**
     * The distance trip in km.
     */
    val distance: Double = 0.0,

    /**
     * The duration trip in horse.
     */
    val duration: Double = 0.0,

    /**
     * The trip rating. Range 1..5
     */
    val rating: Double = 0.0,

    /**
     * The trip phone usage minutes.
     */
    val phoneUsage: Double = 0.0,

    /**
     * The trip type.
     * See also [TrackOriginDictionary.code]
     */
    val originalCode: String?,

    /**
     * The trip type has changed. If false - origin trip type can be changed. If false - can't be changed.
     * [TripOriginDictionary.code]
     */
    val hasOriginChanged: Boolean = false,

    /**
     * Total distance travelled(in km) while exceeding speed limit over for 10 to 20 km/h
     */
    val midOverSpeedMileage: Double = 0.0,

    /**
     * Total distance travelled(in km) while exceeding speed limit over for 20 km/h or more.
     */
    val highOverSpeedMileage: Double = 0.0,

    /**
     * List trip points. Usually used to build a route on the map.
     */
    val points: Array<TrackPoint>?,

    /**
     * Driving tips.
     */
    val drivingTips: String?,

    val shareType: String?,

    val cityStart: String?,

    val cityFinish: String?,

    val ratingCornering: Double = 0.0,

    val ratingAcceleration: Double = 0.0,

    val ratingBraking: Double = 0.0,

    val ratingSpeeding: Double = 0.0,

    val ratingPhoneDistraction: Double = 0.0,

    val ratingTimeOfDay: Double = 0.0,

    /**
     * The trip rating. Range 0..100
     */
    val rating100: Double = 0.toDouble(),

    val ratingCornering100: Double = 0.toDouble(),

    val ratingAcceleration100: Double = 0.toDouble(),

    val ratingBraking100: Double = 0.toDouble(),

    val ratingSpeeding100: Double = 0.toDouble(),

    val ratingPhoneDistraction100: Double = 0.toDouble(),

    val ratingTimeOfDay100: Double = 0.toDouble(),

    val addressStartParts: AddressParts?,

    val addressFinishParts: AddressParts?,

    /**
     * List of tags.
     */
    val tags: Array<TrackTag>?
) {
    override fun toString(): String {
        return "TrackDetails(addressStart=$addressStart, addressEnd=$addressEnd, endDate=$endDate, startDate=$startDate, trackId=$trackId, accelerationCount=$accelerationCount, decelerationCount=$decelerationCount, distance=$distance, duration=$duration, rating=$rating, phoneUsage=$phoneUsage, originalCode=$originalCode, hasOriginChanged=$hasOriginChanged, midOverSpeedMileage=$midOverSpeedMileage, highOverSpeedMileage=$highOverSpeedMileage, points=${points?.contentToString()}, drivingTips=$drivingTips, shareType=$shareType, cityStart=$cityStart, cityFinish=$cityFinish, ratingCornering=$ratingCornering, ratingAcceleration=$ratingAcceleration, ratingBraking=$ratingBraking, ratingSpeeding=$ratingSpeeding, ratingPhoneDistraction=$ratingPhoneDistraction, ratingTimeOfDay=$ratingTimeOfDay, rating100=$rating100, ratingCornering100=$ratingCornering100, ratingAcceleration100=$ratingAcceleration100, ratingBraking100=$ratingBraking100, ratingSpeeding100=$ratingSpeeding100, ratingPhoneDistraction100=$ratingPhoneDistraction100, ratingTimeOfDay100=$ratingTimeOfDay100, addressStartParts=$addressStartParts, addressFinishParts=$addressFinishParts, tags=${tags?.contentToString()})"
    }
}

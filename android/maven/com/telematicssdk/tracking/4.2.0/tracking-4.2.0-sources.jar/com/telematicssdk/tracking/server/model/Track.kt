package com.telematicssdk.tracking.server.model

import com.google.gson.annotations.SerializedName
import com.telematicssdk.tracking.model.sensor.Event

class Track(
    var uniqueId: Long,
    @SerializedName("StartDate") var startDate: String,
    @SerializedName("EndDate") var endDate: String,
    @SerializedName("Points") var points: Array<TrackPoint>,
    @SerializedName("StartReason") var startReason: String,
    @SerializedName("StopReason") var stopReason: String,
    @SerializedName("LastKnownPoints") var lastPoints: Array<TrackLastKnownPoint>,
    @SerializedName("Events") var events: Array<Event>
)

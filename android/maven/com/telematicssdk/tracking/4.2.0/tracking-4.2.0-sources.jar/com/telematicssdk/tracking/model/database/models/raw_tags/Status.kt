package com.telematicssdk.tracking.model.database.models.raw_tags

/**
 * Status about tags operations
 */
enum class Status {
    /**
     * Tag operation was successfully performed on server
     */
    SUCCESS, // successfully added/removed

    /**
     * Unable to establish connection with server
     */
    OFFLINE, // unable to establish connection with server

    /**
     * Unable to perform operation on server
     */
    ERROR_TAG_OPERATION,

    /**
     * Invalid tag name specified (null or empty string)
     */
    ERROR_INVALID_TAG_SPECIFIED,

    /**
     * Future time specified
     */
    ERROR_WRONG_TIME,

    /**
     * Invalid Device ID specified
     */
    ERROR_INVALID_DEVICE_ID,
}

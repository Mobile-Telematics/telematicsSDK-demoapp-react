package com.telematicssdk.tracking.model.sensor

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.telematicssdk.tracking.utils.Scale
import kotlinx.parcelize.Parcelize

@Parcelize
data class RangeValue(
    @Scale(4)
    @SerializedName("max")
    var max: Double = 0.0,

    @Scale(4)
    @SerializedName("quantile_95")
    var quantile_95: Double = 0.0,

    @Scale(4)
    @SerializedName("median")
    var median: Double = 0.0,

    @Scale(4)
    @SerializedName("quantile_05")
    var quantile_05: Double = 0.0,

    @Scale(4)
    @SerializedName("min")
    var min: Double = 0.0,

    @Scale(4)
    @SerializedName("quantile_25")
    var quantile_25: Double = 0.0,

    @Scale(4)
    @SerializedName("quantile_75")
    var quantile_75: Double = 0.0,
) : Parcelable {

    override fun toString(): String {
        return "RangeValue(max=$max, quantile_95=$quantile_95, median=$median, quantile_05=$quantile_05, min=$min, quantile_25=$quantile_25, quantile_75=$quantile_75)"
    }
}
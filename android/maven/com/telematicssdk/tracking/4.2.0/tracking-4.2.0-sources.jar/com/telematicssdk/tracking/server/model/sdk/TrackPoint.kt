package com.telematicssdk.tracking.server.model.sdk

data class TrackPoint(
    /**
     * Order number of trip.
     */
    var number: Int = 0,

    /**
     * Total distance in meters.
     */
    var totalMeters: Double = 0.toDouble(),

    /**
     * Current speed in km/h.
     */
    var speed: Double = 0.toDouble(),

    /**
     * Timestamp in "yyyy-MM-dd'T'HH:mm:ss ZZ" format.
     */
    var pointDate: String? = null,

    /**
     * Latitude point, in degrees.
     */
    var latitude: Double = 0.toDouble(),

    /**
     * Longitude point, in degrees.
     */
    var longitude: Double = 0.toDouble(),

    /**
     * Height above sea level in meters.
     */
    var height: Double = 0.toDouble(),

    /**
     * Angle with respect to something (possibly with respect to the direction to the north
     */
    var course: Double = 0.toDouble(),

    /**
     * The angular velocity
     */
    var yaw: Double = 0.toDouble(),

    /**
     * Lateral acceleration.
     */
    var lateral: Double = 0.toDouble(),

    /**
     * Alert type. Maybe:
     * ACCELERATION - 4
     * DECELERATION - 5
     * LATERAL - 6
     * SUPER_DECELERATION - 8
     */
    var alertType: String? = null,

    /**
     * Alert value.
     */
    var alertValue: Double = 0.toDouble(),

    /**
     * Speed type. Maybe: "norm", "mid", "high".
     */
    var speedType: String? = null,

    /**
     * Speed limit in current point.
     */
    var speedLimit: Int = 0,

    /**
     * Was the use of the phone in current point.
     */
    var phoneUsage: Boolean = false,

    /**
     * Was the cornering in current point.
     */
    var cornering: Boolean = false
) {
    override fun toString(): String {
        return "TrackPoint(number=$number, totalMeters=$totalMeters, speed=$speed, pointDate=$pointDate, latitude=$latitude, longitude=$longitude, height=$height, course=$course, yaw=$yaw, lateral=$lateral, alertType=$alertType, alertValue=$alertValue, speedType=$speedType, speedLimit=$speedLimit, phoneUsage=$phoneUsage, cornering=$cornering)"
    }
}
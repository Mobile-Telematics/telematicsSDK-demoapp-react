package com.telematicssdk.tracking

import com.telematicssdk.tracking.model.database.models.raw_tags.Status
import com.telematicssdk.tracking.server.model.sdk.raw_tags.Tag

interface TagsProcessingListener {
    fun onTagAdd(status: Status, tag: Tag, activationTime: Long)
    fun onTagRemove(status: Status, tag: Tag, deactivationTime: Long)
    fun onAllTagsRemove(status: Status, deactivatedTagsCount: Int, time: Long)
    fun onGetTags(status: Status, tags: Array<Tag>?, time: Long)
}

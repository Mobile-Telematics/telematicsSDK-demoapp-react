package com.telematicssdk.tracking

import android.location.Location

interface LocationListener {
    fun onLocationChanged(location: Location?)
}